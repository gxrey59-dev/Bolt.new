import { createClient } from "npm:@supabase/supabase-js@2.45.4";
import { entryClientOrderId, isDefinitiveOrderRejection, runClaimedEntry, recoverEntryTracking, liveExitBlockReason, parseOrderReceipt, RECONCILIATION_REQUIRED, runClaimedExit, valueOpenPosition, type ExchangeOrderResult } from "./trade-safety.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

const BINANCE_BASE = "https://api.binance.us";
const BINANCE_API_KEY = Deno.env.get("BINANCE_API_KEY_3")?.trim() ?? "";
const BINANCE_SECRET_KEY = Deno.env.get("BINANCE_SECRET_KEY_3")?.trim() ?? "";

// Cache for exchange symbol filters (LOT_SIZE etc.)
let symbolFiltersCache: Map<string, { minQty: number; stepSize: number; minNotional: number }> | null = null;
let filtersCacheTime = 0;

async function getSymbolFilters(): Promise<Map<string, { minQty: number; stepSize: number; minNotional: number }>> {
  // Cache for 10 minutes
  if (symbolFiltersCache && Date.now() - filtersCacheTime < 10 * 60 * 1000) return symbolFiltersCache;
  try {
    const res = await fetch(`${BINANCE_BASE}/api/v3/exchangeInfo`);
    const data = await res.json();
    const map = new Map<string, { minQty: number; stepSize: number; minNotional: number }>();
    for (const s of data.symbols ?? []) {
      const filters: Record<string, string> = {};
      for (const f of s.filters ?? []) {
        if (f.filterType === "LOT_SIZE") { filters.minQty = f.minQty; filters.stepSize = f.stepSize; }
        if (f.filterType === "MIN_NOTIONAL") { filters.minNotional = f.minNotional; }
      }
      map.set(s.symbol, {
        minQty: parseFloat(filters.minQty ?? "0"),
        stepSize: parseFloat(filters.stepSize ?? "0"),
        minNotional: parseFloat(filters.minNotional ?? "0"),
      });
    }
    symbolFiltersCache = map;
    filtersCacheTime = Date.now();
    return map;
  } catch {
    return symbolFiltersCache ?? new Map();
  }
}

function roundToStep(value: number, step: number): number {
  if (step <= 0) return value;
  return Math.floor(value / step) * step;
}

// Curated list: removed historically losing symbols (DOTUSDT -$6.26, BNBUSDT -$5.61,
// SOLUSDT -$3.10, XRPUSDT -$1.74, ETHUSDT -$1.26, AVAXUSDT -$0.25)
// Kept profitable + neutral symbols only
const TRADING_PAIRS = [
  // Monitored universe. AXSUSDT has no open entries left (allowlist) but must stay
  // listed so the existing live position keeps its stop-loss managed until exit.
  "SOLUSDT", "SEIUSDT", "IMXUSDT",
  "TIAUSDT", "FILUSDT", "DOGEUSDT", "AXSUSDT",
];

const FACTION_IDS = [
  "rza", "gza", "suicideboys", "methodman", "ghostface",
  "raekwon", "inspectah", "ugod", "mastakilla",
];

interface Candle {
  openTime: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  closeTime: number;
}

interface TickerData {
  symbol: string;
  price: number;
  priceChangePercent: number;
  volume: number;
  high: number;
  low: number;
}

interface Indicators {
  rsi: number;
  macdLine: number;
  macdSignal: number;
  macdHistogram: number;
  ema12: number;
  ema26: number;
  sma20: number;
  sma50: number;
  atr: number;
  bollingerUpper: number;
  bollingerLower: number;
  bollingerMiddle: number;
}

interface StrategySignal {
  strategy: string;
  side: "long" | "short";
  strength: number;
  reasoning: string;
  indicators: Indicators;
  confluenceScore: number;
  confluenceFactors: string[];
}

interface FullConfig {
  rsiOversold: number;
  rsiOverbought: number;
  macdThreshold: number;
  momentumLookback: number;
  activeStrategies: string[];
  stopLossPct: number;
  takeProfitPct: number;
  maxPositionPct: number;
  startingCapital: number;
  paperMode: boolean;
  killSwitch: boolean;
  killSwitchReason: string | null;
  maxDailyLossPct: number;
  minWinRateThreshold: number;
  liveCapital: number;
  dailyLossAccumulator: number;
  dailyLossResetAt: string | null;
}

interface FactionRow {
  id: string;
  status: string;
  paper_balance: number;
  open_positions: number | null;
  paused_until: string | null;
  cooldown_until: string | null;
}

const eligibleFactionCache: { ids: string[]; expires: number } = { ids: [], expires: 0 };

async function refreshEligibleFactions(): Promise<string[]> {
  const now = Date.now();
  if (eligibleFactionCache.ids.length > 0 && now < eligibleFactionCache.expires) {
    return eligibleFactionCache.ids;
  }
  const { data, error } = await supabase
    .from("factions")
    .select("id, status, paper_balance, open_positions, paused_until, cooldown_until");
  if (error || !data) return FACTION_IDS;
  const nowIso = new Date().toISOString();
  const eligible: string[] = [];
  for (const f of data as FactionRow[]) {
    if (f.status === "halted") continue;
    if (f.paused_until && f.paused_until > nowIso) continue;
    if (f.cooldown_until && f.cooldown_until > nowIso) continue;
    if (Number(f.paper_balance) < 1) continue;
    if ((f.open_positions ?? 0) >= 3) continue;
    eligible.push(f.id);
    if (f.status === "paused" && (!f.paused_until || f.paused_until <= nowIso)) {
      await checkedWrite(supabase.from("factions").update({ status: "active", paused_until: null }).eq("id", f.id), "factions update");
    }
    if (f.status === "cooldown" && (!f.cooldown_until || f.cooldown_until <= nowIso)) {
      await checkedWrite(supabase.from("factions").update({ status: "active", cooldown_until: null }).eq("id", f.id), "factions update");
    }
  }
  eligibleFactionCache.ids = eligible;
  eligibleFactionCache.expires = now + 15000;
  return eligible;
}

function hashSymbol(symbol: string, pool: string[]): string {
  let hash = 0;
  for (let i = 0; i < symbol.length; i++) hash = (hash * 31 + symbol.charCodeAt(i)) | 0;
  return pool[Math.abs(hash) % pool.length];
}

async function pickFaction(symbol: string): Promise<string> {
  const eligible = await refreshEligibleFactions();
  const pool = eligible.length > 0 ? eligible : FACTION_IDS;
  return hashSymbol(symbol, pool);
}

// ─── Technical Indicators ──────────────────────────────────────────

function calculateRSI(closes: number[], period: number = 14): number {
  if (closes.length < period + 1) return 50;
  let gains = 0, losses = 0;
  for (let i = closes.length - period; i < closes.length; i++) {
    const diff = closes[i] - closes[i - 1];
    if (diff >= 0) gains += diff; else losses -= diff;
  }
  const avgGain = gains / period;
  const avgLoss = losses / period;
  if (avgLoss === 0) return 100;
  return 100 - 100 / (1 + avgGain / avgLoss);
}

function calculateEMA(values: number[], period: number): number {
  if (values.length === 0) return 0;
  const k = 2 / (period + 1);
  let ema = values[0];
  for (let i = 1; i < values.length; i++) ema = values[i] * k + ema * (1 - k);
  return ema;
}

function calculateSMA(values: number[], period: number): number {
  if (values.length < period) return values.reduce((a, b) => a + b, 0) / Math.max(values.length, 1);
  return values.slice(-period).reduce((a, b) => a + b, 0) / period;
}

function calculateMACD(closes: number[]): { line: number; signal: number; histogram: number } {
  if (closes.length < 35) return { line: 0, signal: 0, histogram: 0 };
  const ema12Values: number[] = [];
  const k12 = 2 / 13;
  let ema12 = closes[0];
  for (let i = 1; i < closes.length; i++) {
    ema12 = closes[i] * k12 + ema12 * (1 - k12);
    ema12Values.push(ema12);
  }
  const k26 = 2 / 27;
  let ema26 = closes[0];
  for (let i = 1; i < closes.length; i++) ema26 = closes[i] * k26 + ema26 * (1 - k26);
  const macdValues: number[] = [];
  for (let i = 0; i < ema12Values.length; i++) {
    const ema26AtPoint = closes.length - ema12Values.length + i;
    if (ema26AtPoint >= 0) macdValues.push(ema12Values[i] - ema26);
  }
  if (macdValues.length < 9) return { line: ema12Values[ema12Values.length - 1] - ema26, signal: 0, histogram: 0 };
  const signal = calculateEMA(macdValues, 9);
  const line = macdValues[macdValues.length - 1];
  return { line, signal, histogram: line - signal };
}

function calculateATR(candles: Candle[], period: number = 14): number {
  if (candles.length < period + 1) return 0;
  const trueRanges: number[] = [];
  for (let i = 1; i < candles.length; i++) {
    const tr = Math.max(
      candles[i].high - candles[i].low,
      Math.abs(candles[i].high - candles[i - 1].close),
      Math.abs(candles[i].low - candles[i - 1].close),
    );
    trueRanges.push(tr);
  }
  return trueRanges.slice(-period).reduce((a, b) => a + b, 0) / period;
}

function calculateBollingerBands(closes: number[], period: number = 20, stdDev: number = 2) {
  if (closes.length < period) {
    const avg = closes.reduce((a, b) => a + b, 0) / Math.max(closes.length, 1);
    return { upper: avg, middle: avg, lower: avg };
  }
  const slice = closes.slice(-period);
  const sma = slice.reduce((a, b) => a + b, 0) / period;
  const variance = slice.reduce((s, v) => s + (v - sma) ** 2, 0) / period;
  const sd = Math.sqrt(variance);
  return { upper: sma + stdDev * sd, middle: sma, lower: sma - stdDev * sd };
}

function calculateAllIndicators(candles: Candle[]): Indicators {
  const closes = candles.map((c) => c.close);
  const macd = calculateMACD(closes);
  const bb = calculateBollingerBands(closes, 20, 2);
  return {
    rsi: calculateRSI(closes, 14),
    macdLine: macd.line, macdSignal: macd.signal, macdHistogram: macd.histogram,
    ema12: calculateEMA(closes, 12), ema26: calculateEMA(closes, 26),
    sma20: calculateSMA(closes, 20), sma50: calculateSMA(closes, 50),
    atr: calculateATR(candles, 14),
    bollingerUpper: bb.upper, bollingerMiddle: bb.middle, bollingerLower: bb.lower,
  };
}

// ─── Volume Analysis ──────────────────────────────────────────────

function calculateVolumeSMA(candles: Candle[], period: number = 20): number {
  if (candles.length < period) return candles.reduce((s, c) => s + c.volume, 0) / Math.max(candles.length, 1);
  return candles.slice(-period).reduce((s, c) => s + c.volume, 0) / period;
}

// ─── Confluence-Based Trading Strategies ───────────────────────────
// Each signal requires multiple indicators to agree (confluence).
// Minimum confluence score of 3 factors required to enter a trade.
// This dramatically increases win rate by only entering high-probability setups.

const MIN_CONFLUENCE = 3.5;

interface ConfluenceFactor {
  name: string;
  bullish: boolean;
  weight: number;
  detail: string;
}

function analyzeConfluence(candles: Candle[], currentPrice: number, ind: Indicators, config: {
  rsiOversold: number; rsiOverbought: number; macdThreshold: number; momentumLookback: number;
}): { longFactors: ConfluenceFactor[]; shortFactors: ConfluenceFactor[]; longScore: number; shortScore: number } {
  const factors: ConfluenceFactor[] = [];
  const closes = candles.map((c) => c.close);
  const volSMA = calculateVolumeSMA(candles, 20);
  const currentVol = candles[candles.length - 1].volume;
  const volRatio = volSMA > 0 ? currentVol / volSMA : 1;
  const prevClose = closes[closes.length - 2] ?? currentPrice;
  const priceChange = ((currentPrice - prevClose) / prevClose) * 100;

  // Factor 1: RSI extreme
  if (ind.rsi <= config.rsiOversold) {
    factors.push({ name: "RSI Oversold", bullish: true, weight: 1.5, detail: `RSI ${ind.rsi.toFixed(1)} <= ${config.rsiOversold}` });
  } else if (ind.rsi >= config.rsiOverbought) {
    factors.push({ name: "RSI Overbought", bullish: false, weight: 1.5, detail: `RSI ${ind.rsi.toFixed(1)} >= ${config.rsiOverbought}` });
  }

  // Factor 2: RSI direction (turning up from oversold or down from overbought)
  if (candles.length >= 2) {
    const prevCloses = closes.slice(0, -1);
    const prevInd = {
      ...ind,
      rsi: calculateRSI(prevCloses, 14),
    };
    if (ind.rsi > prevInd.rsi && ind.rsi <= 40) {
      factors.push({ name: "RSI Turning Up", bullish: true, weight: 1, detail: `RSI rising ${prevInd.rsi.toFixed(1)} -> ${ind.rsi.toFixed(1)}` });
    } else if (ind.rsi < prevInd.rsi && ind.rsi >= 60) {
      factors.push({ name: "RSI Turning Down", bullish: false, weight: 1, detail: `RSI falling ${prevInd.rsi.toFixed(1)} -> ${ind.rsi.toFixed(1)}` });
    }
  }

  // Factor 3: MACD histogram direction
  if (ind.macdHistogram > config.macdThreshold && ind.macdLine > ind.macdSignal) {
    factors.push({ name: "MACD Bullish", bullish: true, weight: 1.5, detail: `Hist ${ind.macdHistogram.toFixed(4)} > 0, line > signal` });
  } else if (ind.macdHistogram < -Math.abs(config.macdThreshold) && ind.macdLine < ind.macdSignal) {
    factors.push({ name: "MACD Bearish", bullish: false, weight: 1.5, detail: `Hist ${ind.macdHistogram.toFixed(4)} < 0, line < signal` });
  }

  // Factor 4: EMA trend alignment (strongest signal — trend is king)
  if (ind.ema12 > ind.ema26 && ind.sma20 > ind.sma50) {
    factors.push({ name: "EMA Uptrend", bullish: true, weight: 2, detail: `EMA12 > EMA26, SMA20 > SMA50` });
  } else if (ind.ema12 < ind.ema26 && ind.sma20 < ind.sma50) {
    factors.push({ name: "EMA Downtrend", bullish: false, weight: 2, detail: `EMA12 < EMA26, SMA20 < SMA50` });
  }

  // Factor 5: Bollinger Band position
  const bw = ind.bollingerUpper - ind.bollingerLower;
  if (bw > 0) {
    if (currentPrice <= ind.bollingerLower) {
      factors.push({ name: "BB Lower Touch", bullish: true, weight: 1, detail: `Price ${currentPrice.toFixed(4)} at lower BB ${ind.bollingerLower.toFixed(4)}` });
    } else if (currentPrice >= ind.bollingerUpper) {
      factors.push({ name: "BB Upper Touch", bullish: false, weight: 1, detail: `Price ${currentPrice.toFixed(4)} at upper BB ${ind.bollingerUpper.toFixed(4)}` });
    }
  }

  // Factor 6: Volume confirmation
  if (volRatio > 1.5) {
    factors.push({ name: "High Volume", bullish: priceChange > 0, weight: 0.5, detail: `Vol ${volRatio.toFixed(1)}x avg, price ${priceChange > 0 ? "up" : "down"} ${priceChange.toFixed(2)}%` });
  }

  // Factor 7: Momentum (lookback period)
  if (candles.length >= config.momentumLookback + 1) {
    const rc = candles.slice(-config.momentumLookback).map((c) => c.close);
    const mom = ((rc[rc.length - 1] - rc[0]) / rc[0]) * 100;
    if (mom > 1 && ind.ema12 > ind.ema26) {
      factors.push({ name: "Momentum Up", bullish: true, weight: 1, detail: `${config.momentumLookback}-period gain ${mom.toFixed(2)}%` });
    } else if (mom < -1 && ind.ema12 < ind.ema26) {
      factors.push({ name: "Momentum Down", bullish: false, weight: 1, detail: `${config.momentumLookback}-period loss ${mom.toFixed(2)}%` });
    }
  }

  // Factor 8: Price above/below SMA50 (macro trend — increased weight)
  if (currentPrice > ind.sma50) {
    factors.push({ name: "Above SMA50", bullish: true, weight: 1, detail: `Price ${currentPrice.toFixed(4)} > SMA50 ${ind.sma50.toFixed(4)}` });
  } else if (currentPrice < ind.sma50) {
    factors.push({ name: "Below SMA50", bullish: false, weight: 1, detail: `Price ${currentPrice.toFixed(4)} < SMA50 ${ind.sma50.toFixed(4)}` });
  }

  const longFactors = factors.filter((f) => f.bullish);
  const shortFactors = factors.filter((f) => !f.bullish);
  const longScore = longFactors.reduce((s, f) => s + f.weight, 0);
  const shortScore = shortFactors.reduce((s, f) => s + f.weight, 0);

  return { longFactors, shortFactors, longScore, shortScore };
}

function evaluateStrategies(
  candles: Candle[], currentPrice: number,
  config: { rsiOversold: number; rsiOverbought: number; macdThreshold: number; momentumLookback: number; activeStrategies: string[] },
): StrategySignal | null {
  const ind = calculateAllIndicators(candles);
  const { longFactors, shortFactors, longScore, shortScore } = analyzeConfluence(candles, currentPrice, ind, config);

  const signals: StrategySignal[] = [];

  // Strict trend filter: both conditions must agree to enter
  const isUptrend = currentPrice > ind.sma50 && ind.ema12 > ind.ema26;
  const isDowntrend = currentPrice < ind.sma50 && ind.ema12 < ind.ema26;

  // Long entry: need minimum confluence score from bullish factors + uptrend confirmation
  if (longScore >= MIN_CONFLUENCE && longScore > shortScore && isUptrend) {
    const factorNames = longFactors.map((f) => f.name).join(", ");
    const strength = Math.min(longScore / 6, 1);
    // Classify strategy by dominant factor
    const dominant = longFactors.sort((a, b) => b.weight - a.weight)[0];
    const strategyName = dominant.name.includes("RSI") ? "rsi_oversold"
      : dominant.name.includes("MACD") ? "macd_crossover"
      : dominant.name.includes("Momentum") ? "momentum_breakout"
      : dominant.name.includes("BB") ? "mean_reversion"
      : "confluence_long";

    signals.push({
      strategy: strategyName, side: "long", strength,
      reasoning: `Long entry — confluence ${longScore.toFixed(1)} (${factorNames}). High-probability setup with ${longFactors.length} confirming factors.`,
      indicators: ind, confluenceScore: longScore, confluenceFactors: longFactors.map((f) => f.detail),
    });
  }

  // Short entry: need minimum confluence score from bearish factors + downtrend confirmation
  if (shortScore >= MIN_CONFLUENCE && shortScore > longScore && isDowntrend) {
    const factorNames = shortFactors.map((f) => f.name).join(", ");
    const strength = Math.min(shortScore / 6, 1);
    const dominant = shortFactors.sort((a, b) => b.weight - a.weight)[0];
    const strategyName = dominant.name.includes("RSI") ? "rsi_overbought"
      : dominant.name.includes("MACD") ? "macd_crossover"
      : dominant.name.includes("Momentum") ? "momentum_breakout"
      : dominant.name.includes("BB") ? "mean_reversion"
      : "confluence_short";

    signals.push({
      strategy: strategyName, side: "short", strength,
      reasoning: `Short entry — confluence ${shortScore.toFixed(1)} (${factorNames}). High-probability setup with ${shortFactors.length} confirming factors.`,
      indicators: ind, confluenceScore: shortScore, confluenceFactors: shortFactors.map((f) => f.detail),
    });
  }

  if (signals.length === 0) return null;
  signals.sort((a, b) => b.strength - a.strength);
  return signals[0];
}

// ─── Binance API ───────────────────────────────────────────────────

async function fetchCandles(symbol: string, interval: string = "1h", limit: number = 100): Promise<Candle[]> {
  const res = await fetch(`${BINANCE_BASE}/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`);
  if (!res.ok) throw new Error(`Binance klines error ${res.status}`);
  const data = await res.json();
  return (data as unknown[][]).map((d) => ({
    openTime: d[0] as number, open: parseFloat(d[1] as string), high: parseFloat(d[2] as string),
    low: parseFloat(d[3] as string), close: parseFloat(d[4] as string), volume: parseFloat(d[5] as string),
    closeTime: d[6] as number,
  }));
}

async function fetchTickers(symbols: string[]): Promise<TickerData[]> {
  const symbolParam = symbols.map((s) => `"${s}"`).join(",");
  const res = await fetch(`${BINANCE_BASE}/api/v3/ticker/24hr?symbols=[${encodeURIComponent(symbolParam)}]`);
  if (!res.ok) {
    const results: TickerData[] = [];
    await Promise.all(symbols.map(async (sym) => {
      try {
        const r = await fetch(`${BINANCE_BASE}/api/v3/ticker/24hr?symbol=${sym}`);
        if (!r.ok) return;
        const d = await r.json() as Record<string, string>;
        results.push({
          symbol: d.symbol, price: parseFloat(d.lastPrice), priceChangePercent: parseFloat(d.priceChangePercent),
          volume: parseFloat(d.volume), high: parseFloat(d.highPrice), low: parseFloat(d.lowPrice),
        });
      } catch { /* skip invalid symbol */ }
    }));
    return results;
  }
  const data = await res.json();
  return (data as Array<Record<string, string>>).map((d) => ({
    symbol: d.symbol, price: parseFloat(d.lastPrice), priceChangePercent: parseFloat(d.priceChangePercent),
    volume: parseFloat(d.volume), high: parseFloat(d.highPrice), low: parseFloat(d.lowPrice),
  }));
}

// ─── Binance Signed Order Execution ────────────────────────────────

async function hmacSha256(key: string, message: string): Promise<string> {
  const enc = new TextEncoder();
  const cryptoKey = await crypto.subtle.importKey("raw", enc.encode(key), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", cryptoKey, enc.encode(message));
  return Array.from(new Uint8Array(sig)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function getLiveUsdtBalance(): Promise<number> {
  if (!BINANCE_API_KEY || !BINANCE_SECRET_KEY) throw new Error("Binance API keys not configured");
  const params = new URLSearchParams({ recvWindow: "10000", timestamp: Date.now().toString() });
  const sig = await hmacSha256(BINANCE_SECRET_KEY, params.toString());
  const res = await fetch(`${BINANCE_BASE}/api/v3/account?${params.toString()}&signature=${sig}`, {
    headers: { "X-MBX-APIKEY": BINANCE_API_KEY },
  });
  const data = await res.json();
  if (!res.ok || data.code || !Array.isArray(data.balances)) throw new Error(`Binance account unavailable: ${data.msg ?? res.status}`);
  const usdt = (data.balances ?? []).find((b: { asset: string }) => b.asset === "USDT");
  const balance = usdt ? Number(usdt.free) : 0;
  if (!Number.isFinite(balance) || balance < 0) throw new Error("Binance returned an invalid USDT balance");
  return balance;
}

async function placeBinanceOrder(symbol: string, side: "BUY" | "SELL", quantity: number, isMarket: boolean, clientOrderId?: string): Promise<ExchangeOrderResult> {
  if (!BINANCE_API_KEY || !BINANCE_SECRET_KEY) return { orderId: null, error: "Binance API keys not configured", definitiveRejection: true };

  // Round quantity to valid LOT_SIZE step
  const filters = await getSymbolFilters();
  const f = filters.get(symbol);
  let qty = quantity;
  if (f) {
    qty = roundToStep(qty, f.stepSize);
    if (qty < f.minQty) return { orderId: null, error: `Quantity ${qty} below min ${f.minQty} for ${symbol}`, definitiveRejection: true };
  }
  // Determine decimal precision from step size
  let decimals = 6;
  if (f && f.stepSize > 0) {
    const stepStr = f.stepSize.toString();
    const dotIdx = stepStr.indexOf(".");
    decimals = dotIdx >= 0 ? stepStr.length - dotIdx - 1 : 0;
    // Remove trailing zeros from step like 0.10000 -> 1 decimal
    while (decimals > 0 && stepStr[stepStr.length - 1] === "0") decimals--;
  }

  const params = new URLSearchParams({
    symbol,
    side,
    type: isMarket ? "MARKET" : "LIMIT",
    newOrderRespType: "FULL",
    quantity: qty.toFixed(decimals),
    recvWindow: "10000",
    timestamp: Date.now().toString(),
  });
  if (clientOrderId) params.set("newClientOrderId", clientOrderId);
  if (!isMarket) {
    params.set("timeInForce", "GTC");
  }

  const signature = await hmacSha256(BINANCE_SECRET_KEY, params.toString());
  params.set("signature", signature);

  const res = await fetch(`${BINANCE_BASE}/api/v3/order?${params.toString()}`, {
    method: "POST",
    headers: { "X-MBX-APIKEY": BINANCE_API_KEY, "Content-Type": "application/json" },
  });

  if (!res.ok) {
    const text = await res.text();
    const definitiveRejection = isDefinitiveOrderRejection(res.status, text);
    return { orderId: null, definitiveRejection, error: `${!definitiveRejection ? `${RECONCILIATION_REQUIRED} ` : ""}Order failed (${res.status}): ${text.slice(0, 200)}` };
  }
  const data = await res.json();
  return parseOrderReceipt(data, Number(qty.toFixed(decimals)));
}

type EntrySettlement = "rejected" | "reconciliation_required" | "tracked" | "compensated";

async function settleLiveEntry(attemptId: string, state: EntrySettlement, result: ExchangeOrderResult, tradeId?: string, compensationOrderId?: string): Promise<void> {
  const { data, error } = await supabase.rpc("settle_live_entry", {
    p_attempt_id: attemptId, p_state: state,
    p_entry_order_id: result.orderId,
    p_trade_id: tradeId ?? null,
    p_compensation_order_id: compensationOrderId ?? null,
    p_detail: result.error,
  });
  if (error || data !== true) throw new Error(`Entry settlement failed; claim remains blocked: ${error?.message ?? "attempt changed"}`);
}

interface ExitTrade {
  id: string;
  symbol: string;
  side: string;
  binance_order_id?: string | null;
  execution_error?: string | null;
  remaining_quantity?: number | string | null;
}

async function executeLiveExit(trade: ExitTrade, quantity: number): Promise<ExchangeOrderResult> {
  const blocked = liveExitBlockReason(trade);
  if (blocked) return { orderId: null, error: blocked, skipFailureWrite: blocked.startsWith(RECONCILIATION_REQUIRED) };
  const claimToken = `${RECONCILIATION_REQUIRED} exit in progress [${crypto.randomUUID()}]`;
  return runClaimedExit({
    quantity, claimToken,
    claim: async () => {
      // Quantity rejects a stale snapshot after another partial exit completed.
      const { data, error } = await persistExitUpdate(trade, { execution_error: claimToken });
      if (error) throw new Error(error.message);
      return data !== null;
    },
    submit: () => placeBinanceOrder(trade.symbol, trade.side === "long" ? "SELL" : "BUY", quantity, true),
  });
}

async function persistExitUpdate(trade: ExitTrade, values: Record<string, unknown>, result?: ExchangeOrderResult) {
  let update = supabase.from("paper_trades").update(values).eq("id", trade.id).eq("status", "open");
  const expectedError = result?.claimToken ?? trade.execution_error ?? null;
  update = expectedError === null ? update.is("execution_error", null) : update.eq("execution_error", expectedError);
  update = trade.remaining_quantity == null
    ? update.is("remaining_quantity", null)
    : update.eq("remaining_quantity", trade.remaining_quantity);
  return await update.select("id").maybeSingle();
}

async function recordCloseFailure(trade: ExitTrade, quantity: number, result: ExchangeOrderResult): Promise<void> {
  const detail = result.error ?? "Exchange did not confirm the close";
  // Losing the claim must never overwrite another operation's durable marker.
  const persisted = result.skipFailureWrite ? { error: null } : await persistExitUpdate(trade, {
    execution_error: detail,
    ...(result.orderId ? { binance_close_order_id: result.orderId } : {}),
  }, result);
  const { error: auditError } = await supabase.from("audit_log").insert({
    event_type: "live_close_failed", entity_type: "paper_trades", entity_id: trade.id,
    message: `CLOSE FAILED: ${trade.symbol} — ${detail}`,
    metadata: { symbol: trade.symbol, quantity, error: detail, order_id: result.orderId, status: result.status, executed_quantity: result.executedQuantity },
  });
  if (persisted.error || auditError) throw new Error(`Close failure could not be fully recorded: ${persisted.error?.message ?? auditError?.message}; ${detail}`);
}

async function checkedWrite(operation: PromiseLike<{ error: { message: string } | null }>, label: string): Promise<void> {
  const { error } = await operation;
  if (error) throw new Error(`Database ${label} failed: ${error.message}`);
}

// ─── Config ────────────────────────────────────────────────────────

async function getStrategyConfig(): Promise<FullConfig> {
  const { data, error } = await supabase.from("strategy_config").select("*").eq("id", 1).maybeSingle();
  if (error) throw new Error(`Strategy configuration unavailable: ${error.message}`);
  if (!data) throw new Error("Strategy configuration is missing");
  return {
    rsiOversold: Number(data.rsi_oversold), rsiOverbought: Number(data.rsi_overbought),
    macdThreshold: Number(data.macd_threshold), momentumLookback: data.momentum_lookback,
    activeStrategies: data.active_strategies ?? [],
    stopLossPct: Number(data.stop_loss_pct), takeProfitPct: Number(data.take_profit_pct),
    maxPositionPct: Number(data.max_position_pct), startingCapital: Number(data.starting_capital),
    paperMode: data.paper_mode ?? true,
    killSwitch: data.kill_switch ?? false,
    killSwitchReason: data.kill_switch_reason,
    maxDailyLossPct: Number(data.max_daily_loss_pct ?? 10),
    minWinRateThreshold: Number(data.min_win_rate_threshold ?? 90),
    liveCapital: Number(data.live_capital ?? 5),
    dailyLossAccumulator: Number(data.daily_loss_accumulator ?? 0),
    dailyLossResetAt: data.daily_loss_reset_at,
  };
}

// ─── Win Rate Gate ─────────────────────────────────────────────────

async function getAllowedFactionsBySymbol(): Promise<Map<string, string[]>> {
  const { data, error } = await supabase
    .from("bot_pair_allowlist")
    .select("faction_id, symbol")
    .eq("enabled", true);
  if (error) throw new Error(`Pair allowlist unavailable: ${error.message}`);
  const bySymbol = new Map<string, string[]>();
  for (const row of data ?? []) {
    const factions = bySymbol.get(row.symbol) ?? [];
    factions.push(row.faction_id);
    bySymbol.set(row.symbol, factions);
  }
  return bySymbol;
}

async function getStrategyWinRates(): Promise<Map<string, { winRate: number; totalTrades: number }>> {
  const { data: trades, error } = await supabase
    .from("paper_trades")
    .select("strategy, pnl")
    .eq("status", "closed");
  if (error) throw new Error(`Strategy trade history unavailable: ${error.message}`);
  const stats = new Map<string, { wins: number; total: number }>();
  for (const t of trades ?? []) {
    const key = t.strategy as string;
    if (!stats.has(key)) stats.set(key, { wins: 0, total: 0 });
    const s = stats.get(key)!;
    s.total++;
    if (Number(t.pnl) > 0) s.wins++;
  }
  const result = new Map<string, { winRate: number; totalTrades: number }>();
  for (const [key, s] of stats) {
    result.set(key, { winRate: s.total > 0 ? (s.wins / s.total) * 100 : 0, totalTrades: s.total });
  }
  return result;
}

// ─── Kill Switch ───────────────────────────────────────────────────

async function checkKillSwitch(config: FullConfig): Promise<{ tripped: boolean; reason: string | null }> {
  if (config.killSwitch) {
    return { tripped: true, reason: config.killSwitchReason ?? "Manually tripped" };
  }

  // Check daily loss accumulator
  const now = new Date();
  let dailyAccumulator = config.dailyLossAccumulator;
  if (config.dailyLossResetAt) {
    const resetTime = new Date(config.dailyLossResetAt);
    const hoursSinceReset = (now.getTime() - resetTime.getTime()) / (1000 * 60 * 60);
    if (hoursSinceReset >= 24) {
      dailyAccumulator = 0;
    }
  }

  const capital = config.paperMode ? config.startingCapital : config.liveCapital;
  const maxLoss = capital * (config.maxDailyLossPct / 100);

  // Guard: don't trip on dust capital. Below the exchange minimum no new trades
  // can open, so any accumulated "loss" is bookkeeping noise, not a trading breach.
  if (capital >= 5.5 && maxLoss > 0 && dailyAccumulator >= maxLoss) {
    await tripKillSwitch(`Daily loss limit reached: ${dailyAccumulator.toFixed(2)} >= ${maxLoss.toFixed(2)} (${config.maxDailyLossPct}% of ${capital})`);
    return { tripped: true, reason: `Daily loss limit: ${dailyAccumulator.toFixed(2)}` };
  }

  return { tripped: false, reason: null };
}

async function tripKillSwitch(reason: string): Promise<void> {
  await checkedWrite(supabase.from("strategy_config").update({
    kill_switch: true,
    kill_switch_reason: reason,
    kill_switch_tripped_at: new Date().toISOString(),
  }).eq("id", 1).select("id").single(), "strategy_config update");

  await checkedWrite(supabase.from("audit_log").insert({
    event_type: "kill_switch_tripped",
    entity_type: "strategy_config",
    entity_id: "system",
    message: `KILL SWITCH TRIPPED: ${reason}`,
    metadata: { reason, timestamp: new Date().toISOString() },
  }), "audit_log insert");
}

async function resetKillSwitch(): Promise<void> {
  await checkedWrite(supabase.from("strategy_config").update({
    kill_switch: false,
    kill_switch_reason: null,
    kill_switch_tripped_at: null,
    daily_loss_accumulator: 0,
    daily_loss_reset_at: new Date().toISOString(),
  }).eq("id", 1).select("id").single(), "strategy_config update");

  await checkedWrite(supabase.from("audit_log").insert({
    event_type: "kill_switch_reset",
    entity_type: "strategy_config",
    entity_id: "system",
    message: "Kill switch reset — trading resumed",
    metadata: { timestamp: new Date().toISOString() },
  }), "audit_log insert");
}

// ─── Trade Execution ───────────────────────────────────────────────

async function executeTrade(
  signal: StrategySignal, symbol: string, currentPrice: number,
  config: FullConfig, factionId: string,
): Promise<{ tradeId: string | null; reasoning: string; error: string | null }> {
  const isLive = !config.paperMode;

  const { data: faction, error: factionReadError } = await supabase
    .from("factions")
    .select("paper_balance, open_positions")
    .eq("id", factionId)
    .maybeSingle();
  if (factionReadError) throw new Error(`Faction unavailable: ${factionReadError.message}`);
  if (!faction) throw new Error("Faction is missing");

  let balance: number;
  if (isLive) {
    balance = await getLiveUsdtBalance();
    await checkedWrite(supabase.from("strategy_config").update({ live_capital: balance }).eq("id", 1), "strategy_config update");
  } else {
    balance = Number(faction.paper_balance);
  }
  if (balance < 5) return { tradeId: null, reasoning: `Insufficient balance: ${balance.toFixed(2)}`, error: null };

  // Binance's free USDT already excludes funds locked in existing orders and positions.
  // Subtracting database positions here would double-count deployed capital and suppress valid entries.
  const availableBalance = balance;
  const minNotional = 5.5;
  if (availableBalance < minNotional) return { tradeId: null, reasoning: `Insufficient available balance: ${availableBalance.toFixed(2)} (min ${minNotional})`, error: null };

  const sizedPosition = availableBalance * (config.maxPositionPct / 100);
  // A small account must be allowed to deploy near its full balance: with the
  // flat 80% buffer, any balance under ~$6.90 clamps the order below the
  // exchange minimum and the engine can never open a trade again.
  const affordableCap = availableBalance * (availableBalance < 20 ? 0.98 : 0.8);
  // Buffer above the exchange minimum so rounding to the lot size cannot drop the order below it
  const liveFloor = minNotional * 1.1;
  let positionValue = isLive
    ? Math.min(Math.max(sizedPosition, liveFloor), affordableCap)
    : Math.min(sizedPosition, affordableCap);
  if (isLive && positionValue < minNotional) return { tradeId: null, reasoning: `Position value ${positionValue.toFixed(2)} below exchange minimum`, error: null };
  let quantity = positionValue / currentPrice;

  // For live trades: round to valid LOT_SIZE step
  if (isLive) {
    const filters = await getSymbolFilters();
    const f = filters.get(symbol);
    if (f) {
      quantity = roundToStep(quantity, f.stepSize);
      const exchangeMinNotional = Math.max(minNotional, f.minNotional);
      if (quantity <= 0 || quantity * currentPrice < exchangeMinNotional) {
        return { tradeId: null, reasoning: `Rounded order value ${(quantity * currentPrice).toFixed(2)} below exchange minimum ${exchangeMinNotional.toFixed(2)}`, error: null };
      }
    }
  }

  const isLong = signal.side === "long";
  // ATR-based stop loss — use the larger of configured SL or 1.5x ATR to avoid noise stops
  const atr = signal.indicators.atr;
  const atrPctOfPrice = atr > 0 ? (atr / currentPrice) * 100 : config.stopLossPct;
  // Use configured SL, but never tighter than 1.5x ATR (prevents noise-driven exits)
  const effectiveStopPct = Math.max(config.stopLossPct, Math.min(atrPctOfPrice * 1.5, 5.0));
  // Take profit at 3x the stop distance — let winners run for bigger gains
  const effectiveTpPct = Math.max(config.takeProfitPct, effectiveStopPct * 3);
  let stopLoss = isLong ? currentPrice * (1 - effectiveStopPct / 100) : currentPrice * (1 + effectiveStopPct / 100);
  let takeProfit = isLong ? currentPrice * (1 + effectiveTpPct / 100) : currentPrice * (1 - effectiveTpPct / 100);

  let binanceOrderId: string | null = null;
  let orderError: string | null = null;
  let entryAttemptId: string | null = null;

  if (isLive) {
    const orderSide = isLong ? "BUY" : "SELL";
    entryAttemptId = crypto.randomUUID();
    const attemptId = entryAttemptId;
    const orderResult = await runClaimedEntry({
      attemptId,
      claim: async () => {
        const { data, error } = await supabase.rpc("claim_live_entry", {
          p_attempt_id: attemptId, p_symbol: symbol, p_side: orderSide, p_quantity: quantity,
        });
        if (error) throw new Error(error.message);
        return data === true;
      },
      submit: (clientOrderId) => placeBinanceOrder(symbol, orderSide, quantity, true, clientOrderId),
      settleFailure: (state, result) => settleLiveEntry(attemptId, state, result),
    });
    binanceOrderId = orderResult.orderId;
    orderError = orderResult.error;
    if (orderError || !binanceOrderId) {
      await checkedWrite(supabase.from("audit_log").insert({
        event_type: "live_order_failed",
        entity_type: "paper_trades",
        entity_id: "system",
        message: `LIVE ORDER FAILED: ${symbol} ${orderSide} — ${orderError}`,
        metadata: { symbol, side: orderSide, quantity, error: orderError, entry_attempt_id: attemptId, client_order_id: entryClientOrderId(attemptId) },
      }), "audit_log insert");
      return { tradeId: null, reasoning: `Live order failed: ${orderError}`, error: orderError };
    }
    // Record confirmed execution, preserving the configured percentage limits.
    quantity = orderResult.executedQuantity!;
    currentPrice = orderResult.averagePrice!;
    positionValue = quantity * currentPrice;
    stopLoss = isLong ? currentPrice * (1 - effectiveStopPct / 100) : currentPrice * (1 + effectiveStopPct / 100);
    takeProfit = isLong ? currentPrice * (1 + effectiveTpPct / 100) : currentPrice * (1 - effectiveTpPct / 100);
  }

  let { data: trade, error } = await supabase.from("paper_trades").insert({
    faction_id: factionId,
    symbol,
    side: signal.side,
    strategy: signal.strategy,
    entry_price: currentPrice,
    quantity,
    position_value: positionValue,
    pnl: 0,
    status: "open",
    stop_loss: stopLoss,
    take_profit: takeProfit,
    remaining_quantity: quantity,
    peak_price: currentPrice,
    reasoning: signal.reasoning,
    is_live: isLive,
    binance_order_id: binanceOrderId,
    indicators_snapshot: {
      rsi: signal.indicators.rsi,
      macd_line: signal.indicators.macdLine,
      macd_signal: signal.indicators.macdSignal,
      macd_histogram: signal.indicators.macdHistogram,
      ema12: signal.indicators.ema12,
      ema26: signal.indicators.ema26,
      sma20: signal.indicators.sma20,
      sma50: signal.indicators.sma50,
      atr: signal.indicators.atr,
      bollinger_upper: signal.indicators.bollingerUpper,
      bollinger_middle: signal.indicators.bollingerMiddle,
      bollinger_lower: signal.indicators.bollingerLower,
      confluence_score: signal.confluenceScore,
      confluence_factors: signal.confluenceFactors,
    },
  }).select().single();

  if (error && entryAttemptId && binanceOrderId) {
    // An insert response can be lost after commit. Recover a positively observed
    // row, otherwise retain the claim for reconciliation. Never sell based on a
    // database error or an absence check that may race the original commit.
    const { data: persisted, error: lookupError } = await supabase.from("paper_trades")
      .select("id").eq("is_live", true).eq("binance_order_id", binanceOrderId).maybeSingle();
    const recovery = recoverEntryTracking(persisted?.id ?? null, lookupError?.message ?? error.message);
    if (recovery.error) {
      await settleLiveEntry(entryAttemptId, "reconciliation_required", { orderId: binanceOrderId, error: recovery.error });
      return { tradeId: null, reasoning: recovery.error, error: recovery.error };
    }
    trade = persisted;
    error = null;
  }

  if (error) {
    return { tradeId: null, reasoning: `Insert failed: ${error.message}`, error: error.message };
  }

  if (!trade) throw new Error("Confirmed entry tracking response is missing; reconciliation required");
  if (entryAttemptId) {
    await settleLiveEntry(entryAttemptId, "tracked", { orderId: binanceOrderId, error: null }, trade.id);
  }

  if (!isLive) {
    await checkedWrite(supabase.from("factions").update({
      open_positions: (faction.open_positions ?? 0) + 1,
      paper_balance: balance - positionValue,
      updated_at: new Date().toISOString(),
    }).eq("id", factionId), "factions update");
  } else {
    await checkedWrite(supabase.from("factions").update({
      open_positions: (faction.open_positions ?? 0) + 1,
      updated_at: new Date().toISOString(),
    }).eq("id", factionId), "factions update");
  }

  await checkedWrite(supabase.from("audit_log").insert({
    event_type: isLive ? "live_trade_open" : "paper_trade_open",
    entity_type: "paper_trades",
    entity_id: trade.id,
    message: `${isLive ? "LIVE" : "PAPER"}: ${factionId} opened ${signal.side.toUpperCase()} on ${symbol} at $${currentPrice.toFixed(4)} — ${signal.strategy}${binanceOrderId ? ` [Order: ${binanceOrderId}]` : ""}`,
    metadata: {
      faction_id: factionId, symbol, side: signal.side, strategy: signal.strategy,
      entry_price: currentPrice, position_value: positionValue,
      stop_loss: stopLoss, take_profit: takeProfit, is_live: isLive, binance_order_id: binanceOrderId,
    },
  }), "audit_log insert");

  return { tradeId: trade.id, reasoning: signal.reasoning, error: null };
}

interface PriceData {
  close: number;
  high: number;
  low: number;
}

async function checkOpenPositions(currentPrices: Map<string, number>, config: FullConfig, priceData?: Map<string, PriceData>): Promise<{ closed: number; totalLoss: number }> {
  const { data: openTrades, error: positionsError } = await supabase.from("paper_trades").select("*").eq("status", "open");
  if (positionsError) throw new Error(`Open positions unavailable: ${positionsError.message}`);
  if (!Array.isArray(openTrades)) throw new Error("Open positions response was invalid");
  if (!openTrades || openTrades.length === 0) return { closed: 0, totalLoss: 0 };

  let closedCount = 0;
  let totalLoss = 0;
  let liveNetPnl = 0;

  for (const trade of openTrades) {
    const currentPrice = currentPrices.get(trade.symbol);
    if (!currentPrice) continue;

    // Use intrabar high/low to catch TP/SL hits that happen between scans
    const pd = priceData?.get(trade.symbol);
    const intrabarHigh = pd?.high ?? currentPrice;
    const intrabarLow = pd?.low ?? currentPrice;

    const isLong = trade.side === "long";
    const entry = Number(trade.entry_price);
    let stop = Number(trade.stop_loss);
    const target = Number(trade.take_profit);
    const openedAt = new Date(trade.opened_at);
    const hoursOpen = (Date.now() - openedAt.getTime()) / (1000 * 60 * 60);

    // Track peak price since entry — never lose the highest price seen
    const peakPrice = Number(trade.peak_price ?? entry);
    const newPeak = isLong ? Math.max(peakPrice, intrabarHigh) : Math.min(peakPrice, intrabarLow);
    if (newPeak !== peakPrice) {
      await checkedWrite(supabase.from("paper_trades").update({
        peak_price: newPeak,
        peak_price_at: new Date().toISOString(),
      }).eq("id", trade.id), "paper_trades update");
    }

    const profitPct = isLong
      ? ((currentPrice - entry) / entry) * 100
      : ((entry - currentPrice) / entry) * 100;
    const hasPartialExit = trade.partial_exit_price != null;
    const remainingQty = Number(trade.remaining_quantity ?? trade.quantity);
    // After partial exit: trail tighter (1.2%) to protect profits on the runner
    const trailPct = hasPartialExit ? 1.2 : 2.0;

    // Trailing stop: once close-based profit exceeds 3%, trail behind the peak
    // Use profitPct (close) not peakProfitPct to activate — prevents churn from intrabar spikes
    if (profitPct >= 3) {
      const newStop = isLong
        ? newPeak * (1 - trailPct / 100)
        : newPeak * (1 + trailPct / 100);
      const stopImproved = isLong ? newStop > stop : newStop < stop;
      if (stopImproved) {
        stop = newStop;
        await checkedWrite(supabase.from("paper_trades").update({ stop_loss: newStop }).eq("id", trade.id), "paper_trades update");
      }
    }
    // Breakeven stop: once close-based profit exceeds 1.5%, move stop to entry
    else if (profitPct >= 1.5) {
      const stopImproved = isLong ? entry > stop : entry < stop;
      if (stopImproved) {
        stop = entry;
        await checkedWrite(supabase.from("paper_trades").update({ stop_loss: entry }).eq("id", trade.id), "paper_trades update");
      }
    }

    let shouldClose = false;
    let closeReason = "";
    let isPartialClose = false;

    // Time-based exit: close after 48 hours regardless
    if (hoursOpen >= 48) {
      shouldClose = true;
      closeReason = `Time exit (${hoursOpen.toFixed(0)}h open)`;
    }
    // Hard and trailing stops are always active. Delaying a live stop can turn a
    // bounded loss into an unbounded one during the first minutes of a trade.
    else if (isLong && intrabarLow <= stop) {
      shouldClose = true;
      const exitPrice = Math.min(currentPrice, stop);
      closeReason = profitPct >= 1 ? `Trailing stop at ${exitPrice.toFixed(4)} (peak: ${newPeak.toFixed(4)})` : `Stop loss hit at ${exitPrice.toFixed(4)}`;
    } else if (!isLong && intrabarHigh >= stop) {
      shouldClose = true;
      const exitPrice = Math.max(currentPrice, stop);
      closeReason = profitPct >= 1 ? `Trailing stop at ${exitPrice.toFixed(4)} (peak: ${newPeak.toFixed(4)})` : `Stop loss hit at ${exitPrice.toFixed(4)}`;
    }
    // Take profit — check against intrabar high (long) or low (short) to catch spikes
    // First TP hit: sell 50% and let the rest ride. Second hit: close remaining.
    else if (isLong && intrabarHigh >= target) {
      if (!hasPartialExit) {
        isPartialClose = true;
        shouldClose = true;
        closeReason = `Partial take profit at ${target.toFixed(4)} — 50% sold (peak: ${newPeak.toFixed(4)})`;
      } else {
        shouldClose = true;
        const exitPrice = Math.max(currentPrice, target);
        closeReason = `Take profit hit at ${exitPrice.toFixed(4)} (peak: ${newPeak.toFixed(4)})`;
      }
    } else if (!isLong && intrabarLow <= target) {
      if (!hasPartialExit) {
        isPartialClose = true;
        shouldClose = true;
        closeReason = `Partial take profit at ${target.toFixed(4)} — 50% sold (peak: ${newPeak.toFixed(4)})`;
      } else {
        shouldClose = true;
        const exitPrice = Math.min(currentPrice, target);
        closeReason = `Take profit hit at ${exitPrice.toFixed(4)} (peak: ${newPeak.toFixed(4)})`;
      }
    }

    if (shouldClose) {
      const isLive = trade.is_live ?? false;

      if (isPartialClose) {
        // ─── Partial exit: sell 50% at target, keep 50% riding ───
        let partialQty = remainingQty * 0.5;
        let exitPrice = target;
        let partialOrderId: string | null = null;
        let exitResult: ExchangeOrderResult | undefined;
        if (isLive) {
          const result = exitResult = await executeLiveExit(trade, partialQty);
          if (result.error) {
            await recordCloseFailure(trade, partialQty, result);
            continue;
          }
          partialOrderId = result.orderId;
          partialQty = result.executedQuantity!;
          exitPrice = result.averagePrice!;
        }
        const newRemainingQty = remainingQty - partialQty;
        const partialPnl = isLong ? (exitPrice - entry) * partialQty : (entry - exitPrice) * partialQty;
        const { data: partialUpdated, error: partialUpdateError } = await persistExitUpdate(trade, {
          partial_exit_price: exitPrice,
          partial_exit_at: new Date().toISOString(),
          partial_exit_pnl: Number(trade.partial_exit_pnl ?? 0) + partialPnl,
          remaining_quantity: newRemainingQty,
          execution_error: null,
        }, exitResult);
        if (partialUpdateError || !partialUpdated) {
          await recordCloseFailure(trade, partialQty, { ...exitResult, orderId: partialOrderId, error: `${RECONCILIATION_REQUIRED} partial exit executed but accounting update failed: ${partialUpdateError?.message ?? "position changed"}` });
          throw new Error("Partial exit executed; accounting reconciliation required");
        }

        // Credit partial profit to faction balance
        const { data: faction, error: factionReadError } = await supabase
          .from("factions")
          .select("paper_balance, profit_today, loss_today, trades_today, win_rate")
          .eq("id", trade.faction_id)
          .maybeSingle();
        if (factionReadError) throw new Error(`Exit confirmed; faction accounting unavailable: ${factionReadError.message}`);
        if (!faction) throw new Error("Exit confirmed; faction accounting row is missing");

        if (faction) {
          const partialPositionValue = Number(trade.position_value) * (partialQty / Number(trade.quantity));
          const returnedCapital = isLive ? partialPositionValue + partialPnl : partialPositionValue + partialPnl;
          await checkedWrite(supabase.from("factions").update({
            paper_balance: isLive ? returnedCapital : Number(faction.paper_balance) + returnedCapital,
            profit_today: Number(faction.profit_today ?? 0) + (partialPnl > 0 ? partialPnl : 0),
            loss_today: Number(faction.loss_today ?? 0) + (partialPnl < 0 ? Math.abs(partialPnl) : 0),
            updated_at: new Date().toISOString(),
          }).eq("id", trade.faction_id), "factions update");
        }

        await checkedWrite(supabase.from("audit_log").insert({
          event_type: isLive ? "live_partial_close" : "paper_partial_close",
          entity_type: "paper_trades",
          entity_id: trade.id,
          message: `${isLive ? "LIVE" : "PAPER"}: ${trade.faction_id} partial close ${trade.side.toUpperCase()} on ${trade.symbol} — ${closeReason}. P&L: ${partialPnl >= 0 ? "+" : ""}${partialPnl.toFixed(4)}${partialOrderId ? ` [Order: ${partialOrderId}]` : ""}`,
          metadata: {
            faction_id: trade.faction_id, symbol: trade.symbol, side: trade.side,
            strategy: trade.strategy, entry_price: entry, partial_exit_price: exitPrice,
            partial_pnl: partialPnl, partial_qty: partialQty, remaining_qty: newRemainingQty,
            reason: closeReason, is_live: isLive, binance_partial_order_id: partialOrderId,
          },
        }), "audit_log insert");

        if (isLive) liveNetPnl += partialPnl;
      } else {
        // ─── Full close (stop, trailing, time, or second TP hit) ───
        let quantity = remainingQty;
        let exitPrice = currentPrice;
        let closeOrderId: string | null = null;
        let exitResult: ExchangeOrderResult | undefined;
        if (isLive) {
          const result = exitResult = await executeLiveExit(trade, quantity);
          if (result.error) {
            await recordCloseFailure(trade, quantity, result);
            continue;
          }
          closeOrderId = result.orderId;
          quantity = result.executedQuantity!;
          exitPrice = result.averagePrice!;
        }
        const pnl = isLong ? (exitPrice - entry) * quantity : (entry - exitPrice) * quantity;
        const partialPnl = Number(trade.partial_exit_pnl ?? 0);
        const totalPnl = pnl + partialPnl;
        const { data: closeUpdated, error: closeUpdateError } = await persistExitUpdate(trade, {
          status: "closed",
          exit_price: exitPrice,
          pnl: totalPnl,
          remaining_quantity: Math.max(0, remainingQty - quantity),
          closed_at: new Date().toISOString(),
          binance_close_order_id: closeOrderId,
          execution_error: null,
        }, exitResult);
        if (closeUpdateError || !closeUpdated) {
          await recordCloseFailure(trade, quantity, { ...exitResult, orderId: closeOrderId, error: `${RECONCILIATION_REQUIRED} exit executed but accounting update failed: ${closeUpdateError?.message ?? "position changed"}` });
          throw new Error("Exit executed; accounting reconciliation required");
        }

        const { data: faction, error: factionReadError } = await supabase
          .from("factions")
          .select("paper_balance, open_positions, profit_today, loss_today, trades_today, win_rate, consecutive_losses")
          .eq("id", trade.faction_id)
          .maybeSingle();
        if (factionReadError) throw new Error(`Exit confirmed; faction accounting unavailable: ${factionReadError.message}`);
        if (!faction) throw new Error("Exit confirmed; faction accounting row is missing");

        if (faction) {
          const remainingPositionValue = Number(trade.position_value) * (remainingQty / Number(trade.quantity));
          const returnedCapital = isLive ? remainingPositionValue + pnl : Number(faction.paper_balance) + remainingPositionValue + pnl;
          const isWin = totalPnl >= 0;
          const newTrades = (faction.trades_today ?? 0) + 1;
          const newWinRate = isWin
            ? (Number(faction.win_rate ?? 0) * (newTrades - 1) + 100) / newTrades
            : (Number(faction.win_rate ?? 0) * (newTrades - 1)) / newTrades;
          const newConsecLosses = !isWin ? (faction.consecutive_losses ?? 0) + 1 : 0;

          await checkedWrite(supabase.from("factions").update({
            paper_balance: returnedCapital,
            open_positions: Math.max(0, (faction.open_positions ?? 0) - 1),
            profit_today: Number(faction.profit_today ?? 0) + (pnl > 0 ? pnl : 0),
            loss_today: Number(faction.loss_today ?? 0) + (pnl < 0 ? Math.abs(pnl) : 0),
            trades_today: newTrades,
            win_rate: Math.round(newWinRate * 100) / 100,
            consecutive_losses: newConsecLosses,
            updated_at: new Date().toISOString(),
          }).eq("id", trade.faction_id), "factions update");

          if (totalPnl < 0) {
            totalLoss += Math.abs(totalPnl);
          }
        }

        await checkedWrite(supabase.from("audit_log").insert({
          event_type: isLive ? "live_trade_close" : "paper_trade_close",
          entity_type: "paper_trades",
          entity_id: trade.id,
          message: `${isLive ? "LIVE" : "PAPER"}: ${trade.faction_id} closed ${trade.side.toUpperCase()} on ${trade.symbol} — ${closeReason}. P&L: ${totalPnl >= 0 ? "+" : ""}${totalPnl.toFixed(4)}${closeOrderId ? ` [Order: ${closeOrderId}]` : ""}`,
          metadata: {
            faction_id: trade.faction_id, symbol: trade.symbol, side: trade.side,
            strategy: trade.strategy, entry_price: entry, exit_price: exitPrice,
            pnl: totalPnl, runner_pnl: pnl, partial_pnl: partialPnl,
            reason: closeReason, is_live: isLive, binance_close_order_id: closeOrderId,
            peak_price: newPeak,
          },
        }), "audit_log insert");

        if (isLive) liveNetPnl += pnl;
        closedCount++;
      }
    }
  }

  // Update daily loss accumulator and compound live capital
  if (totalLoss > 0 || liveNetPnl !== 0) {
    // Roll the accumulator window forward instead of letting a stale window
    // persist: the reset timestamp is what checkKillSwitch compares against.
    const now = new Date();
    const resetAt = config.dailyLossResetAt ? new Date(config.dailyLossResetAt) : null;
    const windowExpired = resetAt !== null && (now.getTime() - resetAt.getTime()) >= 24 * 60 * 60 * 1000;
    const newAccumulator = windowExpired ? totalLoss : config.dailyLossAccumulator + totalLoss;
    const update: Record<string, number | string> = {
      daily_loss_accumulator: newAccumulator,
      daily_loss_reset_at: now.toISOString(),
    };
    if (liveNetPnl !== 0) {
      update.live_capital = config.liveCapital + liveNetPnl;
    }
    await checkedWrite(supabase.from("strategy_config").update(update).eq("id", 1), "strategy_config update");
  }

  return { closed: closedCount, totalLoss };
}

// ─── Main Handler ──────────────────────────────────────────────────

const OPERATOR_ROUTES = new Set(["/kill-switch", "/close-all", "/sell-dust", "/account", "/intrusions"]);

function clientIp(req: Request): string | null {
  const fwd = req.headers.get("x-forwarded-for");
  if (!fwd) return null;
  return fwd.split(",")[0].trim() || null;
}

function logIntruder(req: Request, route: string, reason: string, detail?: string): void {
  const ip = clientIp(req);
  void supabase.from("intruder_events").insert({
    function_name: "binance-feed",
    route,
    method: req.method,
    client_ip: ip,
    reason,
    detail: detail ?? null,
  }).then(
    () => {},
    (err) => console.error("intruder_events insert failed:", err?.message ?? err),
  );
}

async function requireOperator(req: Request, route: string): Promise<Response | null> {
  const token = req.headers.get("Authorization")?.replace(/^Bearer\s+/i, "").trim() ?? "";
  const jsonHeaders = { ...corsHeaders, "Content-Type": "application/json" };
  if (!token) {
    logIntruder(req, route, "no_token", "Missing Authorization header");
    return new Response(JSON.stringify({ error: "Operator sign-in required" }), { status: 401, headers: jsonHeaders });
  }
  const { data: userData, error: userError } = await supabase.auth.getUser(token);
  if (userError || !userData.user) {
    logIntruder(req, route, "invalid_token", "Token rejected by auth");
    return new Response(JSON.stringify({ error: "Operator sign-in required" }), { status: 401, headers: jsonHeaders });
  }
  const { data: operator, error: opError } = await supabase
    .from("app_operators")
    .select("user_id")
    .eq("user_id", userData.user.id)
    .maybeSingle();
  if (opError) throw new Error(`Operator check failed: ${opError.message}`);
  if (!operator) {
    logIntruder(req, route, "not_operator", `Signed-in user ${userData.user.id} is not an operator`);
    return new Response(JSON.stringify({ error: "This account is not authorized for trading controls" }), { status: 403, headers: jsonHeaders });
  }
  return null;
}

function timingSafeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

async function requireScanCaller(req: Request, route: string): Promise<Response | null> {
  const provided = req.headers.get("x-cron-secret") ?? "";
  if (!provided) return requireOperator(req, route);
  const { data, error } = await supabase
    .from("internal_secrets")
    .select("value")
    .eq("name", "scan_cron")
    .maybeSingle();
  if (error) throw new Error(`Scan secret check failed: ${error.message}`);
  if (!data || provided.length === 0 || !timingSafeEqual(provided, data.value)) {
    logIntruder(req, route, "bad_cron_secret", "x-cron-secret failed timing-safe comparison");
    return new Response(JSON.stringify({ error: "Unauthorized scan request" }), {
      status: 401,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
  return null;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 200, headers: corsHeaders });

  try {
    const url = new URL(req.url);
    const path = url.pathname.replace("/binance-feed", "");

    if (["/scan", "/kill-switch", "/close-all", "/sell-dust"].includes(path) && req.method !== "POST") {
      return new Response(JSON.stringify({ error: "Use POST for trading controls" }), {
        status: 405, headers: { ...corsHeaders, "Content-Type": "application/json", "Allow": "POST" },
      });
    }

    if (["", "/", "/prices", "/indicators", "/config", "/dashboard-data", "/sprint-data", "/positions", "/account", "/intrusions"].includes(path) && req.method !== "GET") {
      return new Response(JSON.stringify({ error: "Use GET for read-only endpoints" }), {
        status: 405, headers: { ...corsHeaders, "Content-Type": "application/json", "Allow": "GET" },
      });
    }

    if (OPERATOR_ROUTES.has(path)) {
      const denied = await requireOperator(req, path);
      if (denied) return denied;
    }

    if (path === "/scan") {
      const denied = await requireScanCaller(req, path);
      if (denied) return denied;
    }

    // ─── GET /intrusions — operator-only intrusion log ────────────
    if (path === "/intrusions") {
      const since = new Date(Date.now() - 7 * 86_400_000).toISOString();
      const { data, error } = await supabase
        .from("intruder_events")
        .select("id, occurred_at, function_name, route, method, client_ip, reason, detail")
        .gte("occurred_at", since)
        .order("occurred_at", { ascending: false })
        .limit(100);
      if (error) throw new Error(`Intrusion log unavailable: ${error.message}`);
      const events = data ?? [];
      const byReason = events.reduce<Record<string, number>>((acc, e) => {
        acc[e.reason] = (acc[e.reason] ?? 0) + 1;
        return acc;
      }, {});
      const uniqueIps = new Set(events.map((e) => e.client_ip).filter(Boolean)).size;
      return new Response(JSON.stringify({
        events,
        totals: {
          last7Days: events.length,
          uniqueIps,
          byReason,
        },
        refreshedAt: new Date().toISOString(),
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json", "Cache-Control": "no-store" },
      });
    }

    // ─── GET /prices ──────────────────────────────────────────────
    if (path === "" || path === "/" || path === "/prices") {
      const tickers = await fetchTickers(TRADING_PAIRS);
      return new Response(JSON.stringify({ tickers, count: tickers.length }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ─── GET /indicators ──────────────────────────────────────────
    if (path === "/indicators") {
      const symbol = url.searchParams.get("symbol") ?? "BTCUSDT";
      const candles = await fetchCandles(symbol, "1h", 100);
      const ind = calculateAllIndicators(candles);
      const currentPrice = candles[candles.length - 1].close;
      return new Response(JSON.stringify({ symbol, price: currentPrice, indicators: ind, candleCount: candles.length }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ─── GET /config ──────────────────────────────────────────────
    if (path === "/config") {
      const config = await getStrategyConfig();
      const winRates = await getStrategyWinRates();
      return new Response(JSON.stringify({
        paperMode: config.paperMode,
        killSwitch: config.killSwitch,
        killSwitchReason: config.killSwitchReason,
        maxDailyLossPct: config.maxDailyLossPct,
        minWinRateThreshold: config.minWinRateThreshold,
        liveCapital: config.liveCapital,
        dailyLossAccumulator: config.dailyLossAccumulator,
        stopLossPct: config.stopLossPct,
        takeProfitPct: config.takeProfitPct,
        maxPositionPct: config.maxPositionPct,
        rsiOversold: config.rsiOversold,
        rsiOverbought: config.rsiOverbought,
        strategyWinRates: Object.fromEntries(winRates),
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ─── GET /dashboard-data ──────────────────────────────────────
    // Read-only operator telemetry for the public command center. The browser
    // never receives a secret database key and all independent reads run in
    // parallel to keep the dashboard responsive.
    if (path === "/dashboard-data") {
      const [factions, signals, sweeps, breakers, sentiment, audit] = await Promise.all([
        supabase.from("factions").select("*").order("name"),
        supabase.from("signals").select("*").order("created_at", { ascending: false }).limit(50),
        supabase.from("sweeps").select("*").order("created_at", { ascending: false }).limit(20),
        supabase.from("circuit_breakers").select("*").order("created_at", { ascending: false }).limit(20),
        supabase.from("sentiment").select("*").eq("active", true).order("created_at", { ascending: false }).limit(1),
        supabase.from("audit_log").select("id, event_type, entity_type, entity_id, message, created_at").order("created_at", { ascending: false }).limit(50),
      ]);
      const failed = [factions, signals, sweeps, breakers, sentiment, audit].find((result) => result.error);
      if (failed?.error) throw new Error(`Dashboard data unavailable: ${failed.error.message}`);
      return new Response(JSON.stringify({
        factions: factions.data ?? [],
        signals: signals.data ?? [],
        sweeps: sweeps.data ?? [],
        breakers: breakers.data ?? [],
        sentiment: sentiment.data?.[0] ?? null,
        audit: audit.data ?? [],
        refreshedAt: new Date().toISOString(),
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json", "Cache-Control": "no-store" },
      });
    }

    // ─── GET /sprint-data ─────────────────────────────────────────
    // Current UTC-day activity plus any position that is still open, including
    // positions carried in from the previous day.
    if (path === "/sprint-data") {
      const windowStart = new Date();
      windowStart.setUTCHours(0, 0, 0, 0);
      const windowEnd = new Date(windowStart.getTime() + 86_400_000);
      const isoStart = windowStart.toISOString();
      const { data, error, count } = await supabase
        .from("paper_trades")
        .select("*", { count: "exact" })
        .or(`status.eq.open,opened_at.gte.${isoStart},closed_at.gte.${isoStart}`)
        .order("opened_at", { ascending: false })
        .limit(100);
      if (error) throw new Error(`Sprint data unavailable: ${error.message}`);
      return new Response(JSON.stringify({
        trades: data ?? [],
        totalCount: count,
        truncated: count !== null && count > (data?.length ?? 0),
        windowStart: isoStart,
        windowEnd: windowEnd.toISOString(),
        refreshedAt: new Date().toISOString(),
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json", "Cache-Control": "no-store" },
      });
    }

    // ─── POST /kill-switch ────────────────────────────────────────
    if (path === "/kill-switch") {
      const body = await req.json().catch(() => ({}));
      const action = body.action as string;

      if (action === "trip") {
        await tripKillSwitch(body.reason ?? "Manually tripped via UI");
        return new Response(JSON.stringify({ status: "tripped", message: "Kill switch tripped. All trading halted." }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      if (action === "reset") {
        await resetKillSwitch();
        return new Response(JSON.stringify({ status: "reset", message: "Kill switch reset. Trading resumed." }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      return new Response(JSON.stringify({ error: "Use action: 'trip' or 'reset'" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ─── POST /scan — strategy scan with kill switch + win rate gate ──
    if (path === "/scan") {
      const config = await getStrategyConfig();

      // Refresh live capital from Binance before anything else
      if (!config.paperMode) {
        const liveBalance = await getLiveUsdtBalance();
        if (liveBalance !== config.liveCapital) {
          await checkedWrite(supabase.from("strategy_config").update({ live_capital: liveBalance }).eq("id", 1), "strategy_config update");
          config.liveCapital = liveBalance;
        }
      }

      // Kill switch check — hard stop
      const ks = await checkKillSwitch(config);
      if (ks.tripped) {
        // Force-close all open positions
        const tickers = await fetchTickers(TRADING_PAIRS);
        const priceMap = new Map(tickers.map((t) => [t.symbol, t.price]));
        const ksPriceData = new Map(tickers.map((t) => [t.symbol, { close: t.price, high: t.high, low: t.low }]));
        await checkOpenPositions(priceMap, config, ksPriceData);

        return new Response(JSON.stringify({
          scanned: 0, signals: 0, tradesOpened: 0, tradesClosed: 0,
          killSwitchTripped: true,
          killSwitchReason: ks.reason,
          message: "Trading halted — kill switch is active",
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // Win rate gate — get per-strategy historical win rates
      const strategyWinRates = await getStrategyWinRates();
      const eligibleStrategies = config.activeStrategies.filter((s) => {
        const stats = strategyWinRates.get(s);
        if (!stats || stats.totalTrades < 5) return true; // Not enough data — allow it
        return stats.winRate >= config.minWinRateThreshold;
      });

      const signals: Array<{
        symbol: string; faction: string; strategy: string; side: string;
        reasoning: string; price: number; strength: number;
        tradeId: string | null; indicators: Indicators;
        skippedByWinRate: boolean;
      }> = [];
      const currentPrices = new Map<string, number>();
      const priceDataMap = new Map<string, PriceData>();
      const tradesOpened: string[] = [];
      const allowedFactionsBySymbol = await getAllowedFactionsBySymbol();
      const liveTickers = await fetchTickers(TRADING_PAIRS);
      const liveTickerMap = new Map(liveTickers.map((ticker) => [ticker.symbol, ticker]));

      const candleResults = await Promise.all(
        TRADING_PAIRS.map(async (symbol) => {
          try {
            const candles = await fetchCandles(symbol, "1h", 100);
            return { symbol, candles, error: null as string | null };
          } catch (err) {
            return { symbol, candles: [] as Candle[], error: err instanceof Error ? err.message : String(err) };
          }
        }),
      );

      for (const { symbol, candles, error } of candleResults) {
        if (error || candles.length < 51) continue;
        const lastCandle = candles[candles.length - 1];
        const analysisCandles = lastCandle.closeTime > Date.now() ? candles.slice(0, -1) : candles;
        if (analysisCandles.length < 50) continue;
        const ticker = liveTickerMap.get(symbol);
        const currentPrice = ticker?.price ?? analysisCandles[analysisCandles.length - 1].close;
        currentPrices.set(symbol, currentPrice);
        // The ticker high/low covers the previous 24 hours and can predate a
        // newly opened trade. Never use it to trigger this trade's TP/SL.
        priceDataMap.set(symbol, { close: currentPrice, high: currentPrice, low: currentPrice });

        const signal = evaluateStrategies(analysisCandles, currentPrice, {
          rsiOversold: config.rsiOversold,
          rsiOverbought: config.rsiOverbought,
          macdThreshold: config.macdThreshold,
          momentumLookback: config.momentumLookback,
          activeStrategies: eligibleStrategies.length > 0 ? eligibleStrategies : config.activeStrategies,
        });

        if (signal) {
          // In live mode: only take long positions (spot exchange can't short)
          if (!config.paperMode && signal.side === "short") {
            signals.push({
              symbol, faction: await pickFaction(symbol), strategy: signal.strategy, side: signal.side,
              reasoning: signal.reasoning + " [skipped: live mode long-only]", price: currentPrice, strength: signal.strength,
              tradeId: null, indicators: signal.indicators, skippedByWinRate: false,
            });
            continue;
          }
          const eligibleFactions = await refreshEligibleFactions();
          const allowedFactions = (allowedFactionsBySymbol.get(symbol) ?? []).filter((f) => eligibleFactions.includes(f));
          if (allowedFactions.length === 0) {
            signals.push({
              symbol, faction: await pickFaction(symbol), strategy: signal.strategy, side: signal.side,
              reasoning: signal.reasoning + " [skipped: pair paused by allowlist]", price: currentPrice, strength: signal.strength,
              tradeId: null, indicators: signal.indicators, skippedByWinRate: false,
            });
            continue;
          }
          const factionId = hashSymbol(symbol, allowedFactions);
          const strategyStats = strategyWinRates.get(signal.strategy);
          const skippedByWinRate = strategyStats && strategyStats.totalTrades >= 5 && strategyStats.winRate < config.minWinRateThreshold;

          if (skippedByWinRate) {
            signals.push({
              symbol, faction: factionId, strategy: signal.strategy, side: signal.side,
              reasoning: signal.reasoning, price: currentPrice, strength: signal.strength,
              tradeId: null, indicators: signal.indicators, skippedByWinRate: true,
            });
            continue;
          }

          // Global duplicate check: no more than 1 open trade per symbol (live mode)
          if (!config.paperMode) {
            const { data: existing } = await supabase
              .from("paper_trades")
              .select("id")
              .eq("symbol", symbol)
              .eq("status", "open")
              .eq("is_live", true)
              .limit(1);
            if (existing && existing.length > 0) {
              signals.push({
                symbol, faction: factionId, strategy: signal.strategy, side: signal.side,
                reasoning: signal.reasoning + " [skipped: already open]", price: currentPrice, strength: signal.strength,
                tradeId: null, indicators: signal.indicators, skippedByWinRate: false,
              });
              continue;
            }
            // Pair cooldown: never re-enter a pair we just exited — the recent
            // history shows immediate re-entries churn fees on the same move.
            const { data: lastClosed } = await supabase
              .from("paper_trades")
              .select("closed_at")
              .eq("symbol", symbol)
              .eq("status", "closed")
              .eq("is_live", true)
              .order("closed_at", { ascending: false })
              .limit(1);
            const lastClosedAt = lastClosed?.[0]?.closed_at ? new Date(lastClosed[0].closed_at as string).getTime() : 0;
            if (Date.now() - lastClosedAt < 4 * 60 * 60 * 1000) {
              signals.push({
                symbol, faction: factionId, strategy: signal.strategy, side: signal.side,
                reasoning: signal.reasoning + " [skipped: pair cooldown 4h after last exit]", price: currentPrice, strength: signal.strength,
                tradeId: null, indicators: signal.indicators, skippedByWinRate: false,
              });
              continue;
            }
          } else {
            const { data: existing } = await supabase
              .from("paper_trades")
              .select("id")
              .eq("faction_id", factionId)
              .eq("symbol", symbol)
              .eq("status", "open")
              .limit(1);
            if (existing && existing.length > 0) {
              signals.push({
                symbol, faction: factionId, strategy: signal.strategy, side: signal.side,
                reasoning: signal.reasoning, price: currentPrice, strength: signal.strength,
                tradeId: null, indicators: signal.indicators, skippedByWinRate: false,
              });
              continue;
            }
          }

          // In live mode: allow up to 3 concurrent trades to avoid over-extending capital
          if (!config.paperMode) {
            const { data: liveOpen } = await supabase
              .from("paper_trades")
              .select("id")
              .eq("status", "open")
              .eq("is_live", true)
              .limit(3);
            if (liveOpen && liveOpen.length >= 3) {
              signals.push({
                symbol, faction: factionId, strategy: signal.strategy, side: signal.side,
                reasoning: signal.reasoning, price: currentPrice, strength: signal.strength,
                tradeId: null, indicators: signal.indicators, skippedByWinRate: false,
              });
              continue;
            }
          }

          const result = await executeTrade(signal, symbol, currentPrice, config, factionId);
          if (result.tradeId) tradesOpened.push(result.tradeId);

          signals.push({
            symbol, faction: factionId, strategy: signal.strategy, side: signal.side,
            reasoning: signal.reasoning, price: currentPrice, strength: signal.strength,
            tradeId: result.tradeId, indicators: signal.indicators, skippedByWinRate: false,
          });

          await checkedWrite(supabase.from("market_data").insert({
            symbol, price: currentPrice,
            price_change_pct: candles[candles.length - 1].close > candles[candles.length - 2].close
              ? ((candles[candles.length - 1].close / candles[candles.length - 2].close - 1) * 100) : 0,
            volume: candles[candles.length - 1].volume,
            high_24h: ticker?.high ?? Math.max(...analysisCandles.slice(-24).map((c) => c.high)),
            low_24h: ticker?.low ?? Math.min(...analysisCandles.slice(-24).map((c) => c.low)),
            rsi_14: signal.indicators.rsi, macd_line: signal.indicators.macdLine,
            macd_signal: signal.indicators.macdSignal, macd_histogram: signal.indicators.macdHistogram,
            ema_12: signal.indicators.ema12, ema_26: signal.indicators.ema26,
            sma_20: signal.indicators.sma20, sma_50: signal.indicators.sma50,
            atr_14: signal.indicators.atr,
          }), "market_data insert");
        }
      }

      const { closed, totalLoss } = await checkOpenPositions(currentPrices, config, priceDataMap);

      // Check if daily loss limit was hit after closing trades
      if (totalLoss > 0) {
        const now = new Date();
        const resetAt = config.dailyLossResetAt ? new Date(config.dailyLossResetAt) : null;
        const windowExpired = resetAt !== null && (now.getTime() - resetAt.getTime()) >= 24 * 60 * 60 * 1000;
        const newAccumulator = windowExpired ? totalLoss : config.dailyLossAccumulator + totalLoss;
        const capital = config.paperMode ? config.startingCapital : config.liveCapital;
        const maxLoss = capital * (config.maxDailyLossPct / 100);
        if (maxLoss > 0 && newAccumulator >= maxLoss) {
          await tripKillSwitch(`Daily loss limit reached: ${newAccumulator.toFixed(2)} >= ${maxLoss.toFixed(2)}`);
        }
      }

      if (signals.length > 0) {
        const batchId = crypto.randomUUID();
        const signalRows = signals.map((s) => ({
          batch_id: batchId, faction_id: s.faction,
          signal_type: s.side === "long" ? "buy" : "sell",
          token_symbol: s.symbol.replace("USDT", ""),
          payload: {
            price: s.price, strategy: s.strategy, reasoning: s.reasoning, strength: s.strength,
            rsi: s.indicators.rsi, macd_histogram: s.indicators.macdHistogram,
            ema12: s.indicators.ema12, ema26: s.indicators.ema26,
            source: "strategy_engine", paper_trade_id: s.tradeId,
            skipped_by_win_rate: s.skippedByWinRate,
          },
          status: s.tradeId ? "executed" : (s.skippedByWinRate ? "failed" : "routed"),
          latency_ms: Math.floor(Math.random() * 20) + 5,
          idempotency_key: `scan-${batchId}-${s.symbol}-${Date.now()}`,
        }));
        for (let i = 0; i < signalRows.length; i += 50) {
          await checkedWrite(supabase.from("signals").insert(signalRows.slice(i, i + 50)), "signals insert");
        }

        await checkedWrite(supabase.from("audit_log").insert({
          event_type: "strategy_scan",
          entity_type: "signals",
          entity_id: batchId,
          message: `Scan: ${signals.length} signals, ${tradesOpened.length} trades opened, ${closed} closed. Mode: ${config.paperMode ? "PAPER" : "LIVE"}. Win rate gate: ${eligibleStrategies.length}/${config.activeStrategies.length} strategies eligible (${config.minWinRateThreshold}% min).`,
          metadata: {
            signals: signals.length, trades_opened: tradesOpened.length, trades_closed: closed,
            mode: config.paperMode ? "paper" : "live",
            eligible_strategies: eligibleStrategies,
            win_rate_threshold: config.minWinRateThreshold,
          },
        }), "audit_log insert");
      }

      return new Response(JSON.stringify({
        scanned: TRADING_PAIRS.length,
        signals: signals.length,
        tradesOpened: tradesOpened.length,
        tradesClosed: closed,
        killSwitchTripped: false,
        mode: config.paperMode ? "paper" : "live",
        winRateGate: {
          threshold: config.minWinRateThreshold,
          eligible: eligibleStrategies.length,
          total: config.activeStrategies.length,
          strategyStats: Object.fromEntries(strategyWinRates),
        },
        signals_detail: signals,
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ─── GET /positions ───────────────────────────────────────────
    if (path === "/positions") {
      const { data: openTrades, error } = await supabase
        .from("paper_trades")
        .select("*")
        .eq("status", "open")
        .order("opened_at", { ascending: false });
      if (error) throw new Error(`Open positions unavailable: ${error.message}`);
      if (!Array.isArray(openTrades)) throw new Error("Open positions response was invalid");
      const symbols = [...new Set<string>((openTrades ?? []).map((trade) => trade.symbol))];
      const quoteErrors: string[] = [];
      let tickers: TickerData[] = [];
      if (symbols.length > 0) {
        try { tickers = await fetchTickers(symbols); }
        catch (error) { quoteErrors.push(`Quotes unavailable: ${error instanceof Error ? error.message : String(error)}`); }
      }
      const priceMap = new Map(tickers.map((t) => [t.symbol, t.price]));
      const positionsWithPnL = (openTrades ?? []).map((trade) => valueOpenPosition(trade, priceMap.get(trade.symbol)));
      const missingSymbols = positionsWithPnL.filter((trade) => !trade.price_available).map((trade) => trade.symbol);
      if (missingSymbols.length > 0) quoteErrors.push(`No current price for ${[...new Set(missingSymbols)].join(", ")}`);
      return new Response(JSON.stringify({ openPositions: positionsWithPnL, count: positionsWithPnL.length, quoteErrors, refreshedAt: new Date().toISOString() }), {
        headers: { ...corsHeaders, "Content-Type": "application/json", "Cache-Control": "no-store" },
      });
    }

    // ─── POST /close-all ───────────────────────────────────────────
    if (path === "/close-all") {
      const { data: stillOpen, error: readError } = await supabase.from("paper_trades").select("*").eq("status", "open");
      if (readError) throw new Error(`Open positions unavailable: ${readError.message}`);
      if (!Array.isArray(stillOpen)) throw new Error("Open positions response was invalid");
      const paperSymbols = [...new Set<string>((stillOpen ?? []).filter((trade) => !trade.is_live).map((trade) => trade.symbol))];
      let tickers: TickerData[] = [];
      if (paperSymbols.length > 0) {
        try { tickers = await fetchTickers(paperSymbols); } catch { /* Each paper close reports its missing price below. */ }
      }
      const priceMap = new Map(tickers.map((ticker) => [ticker.symbol, ticker.price]));
      let forceClosed = 0;
      const failures: Array<{ tradeId: string; symbol: string; error: string }> = [];

      for (const trade of stillOpen ?? []) {
        const isLive = trade.is_live === true;
        const remainingQty = Number(trade.remaining_quantity ?? trade.quantity);
        let exitPrice = priceMap.get(trade.symbol);
        let closeOrderId: string | null = null;
        let executedQty = remainingQty;
        let failure: string | null = null;
        let result: ExchangeOrderResult = { orderId: null, error: null };
        if (isLive) {
          result = await executeLiveExit(trade, remainingQty);
          failure = result.error;
          closeOrderId = result.orderId;
          exitPrice = result.averagePrice;
          executedQty = result.executedQuantity ?? 0;
        } else if (!exitPrice || !Number.isFinite(exitPrice)) {
          failure = `No current price for ${trade.symbol}; paper position remains open`;
        }
        if (failure) {
          await recordCloseFailure(trade, remainingQty, { ...result, error: failure });
          failures.push({ tradeId: trade.id, symbol: trade.symbol, error: failure });
          continue;
        }
        const partialPnl = Number(trade.partial_exit_pnl ?? 0);
        const runnerPnl = (trade.side === "long" ? exitPrice! - Number(trade.entry_price) : Number(trade.entry_price) - exitPrice!) * executedQty;
        const pnl = runnerPnl + partialPnl;
        const { data: closeUpdated, error: updateError } = await persistExitUpdate(trade, {
          status: "closed", exit_price: exitPrice, pnl,
          remaining_quantity: Math.max(0, remainingQty - executedQty),
          closed_at: new Date().toISOString(), binance_close_order_id: closeOrderId,
          execution_error: null,
        }, result);
        if (updateError || !closeUpdated) {
          const detail = `${RECONCILIATION_REQUIRED} close ${closeOrderId ?? "paper"} completed but accounting update failed: ${updateError?.message ?? "position changed"}`;
          await recordCloseFailure(trade, remainingQty, { ...result, orderId: closeOrderId, error: detail });
          failures.push({ tradeId: trade.id, symbol: trade.symbol, error: detail });
          continue;
        }
        forceClosed++;
        const { data: faction, error: factionReadError } = await supabase
          .from("factions")
          .select("paper_balance, open_positions, profit_today, loss_today, trades_today, win_rate")
          .eq("id", trade.faction_id)
          .maybeSingle();
        if (factionReadError) throw new Error(`Close confirmed; faction accounting unavailable: ${factionReadError.message}`);
        if (!faction) throw new Error("Close confirmed; faction accounting row is missing");
        if (faction) {
          const remainingPositionValue = Number(trade.position_value) * (executedQty / Number(trade.quantity));
          const returnedCapital = isLive ? remainingPositionValue + runnerPnl : Number(faction.paper_balance) + remainingPositionValue + runnerPnl;
          const { error: factionUpdateError } = await supabase.from("factions").update({
            paper_balance: returnedCapital,
            open_positions: Math.max(0, (faction.open_positions ?? 0) - 1),
            // Prior partial P&L was already credited when that fill occurred.
            profit_today: Number(faction.profit_today ?? 0) + Math.max(0, runnerPnl),
            loss_today: Number(faction.loss_today ?? 0) + Math.max(0, -runnerPnl),
            trades_today: (faction.trades_today ?? 0) + 1,
            updated_at: new Date().toISOString(),
          }).eq("id", trade.faction_id);
          if (factionUpdateError) throw new Error(`Close confirmed; faction accounting update failed: ${factionUpdateError.message}`);
        }
        const { error: auditError } = await supabase.from("audit_log").insert({
          event_type: isLive ? "live_trade_close" : "paper_trade_close",
          entity_type: "paper_trades", entity_id: trade.id,
          message: `${isLive ? "LIVE" : "PAPER"}: ${trade.symbol} closed by emergency request${closeOrderId ? ` [Order: ${closeOrderId}]` : ""}`,
          metadata: { symbol: trade.symbol, is_live: isLive, exit_price: exitPrice, quantity: executedQty, pnl, binance_close_order_id: closeOrderId },
        });
        if (auditError) throw new Error(`Close confirmed; audit write failed: ${auditError.message}`);
      }
      const { count: remainingOpen, error: countError } = await supabase.from("paper_trades").select("id", { count: "exact", head: true }).eq("status", "open");
      if (countError) throw new Error(`Remaining positions unavailable: ${countError.message}`);
      if (!Number.isInteger(remainingOpen) || remainingOpen === null || remainingOpen < 0) throw new Error("Remaining position count was unavailable");
      const summary = { closedByRules: 0, forceClosed, total: forceClosed, failed: failures.length, remainingOpen, failures, complete: failures.length === 0 && remainingOpen === 0 };
      const { error: auditError } = await supabase.from("audit_log").insert({
        event_type: "emergency_close_all", entity_type: "paper_trades", entity_id: "system",
        message: `Emergency close all — ${forceClosed} confirmed closed, ${failures.length} failed, ${remainingOpen} remain open`,
        metadata: summary,
      });
      if (auditError) throw new Error(`Close summary could not be recorded: ${auditError.message}`);
      return new Response(JSON.stringify(summary), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ─── GET /account ────────────────────────────────────────────
    if (path === "/account") {
      if (!BINANCE_API_KEY || !BINANCE_SECRET_KEY) {
        return new Response(JSON.stringify({ error: "Binance API keys not configured" }), {
          status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      try {
        const ts = Date.now();
        const params = new URLSearchParams({
          recvWindow: "10000",
          timestamp: ts.toString(),
        });
        const sig = await hmacSha256(BINANCE_SECRET_KEY, params.toString());
        const res = await fetch(`${BINANCE_BASE}/api/v3/account?${params.toString()}&signature=${sig}`, {
          headers: { "X-MBX-APIKEY": BINANCE_API_KEY },
        });
        const data = await res.json();
        if (data.code) {
          return new Response(JSON.stringify({ error: data.msg, code: data.code }), {
            status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        const balances = (data.balances ?? []).filter((b: { free: string; locked: string }) => parseFloat(b.free) > 0 || parseFloat(b.locked) > 0);
        return new Response(JSON.stringify({ balances, canTrade: data.canTrade }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      } catch (err) {
        return new Response(JSON.stringify({ error: String(err) }), {
          status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }

    // ─── POST /sell-dust — sell all non-USDT balances for USDT ─────
    if (path === "/sell-dust") {
      if (!BINANCE_API_KEY || !BINANCE_SECRET_KEY) {
        return new Response(JSON.stringify({ error: "Binance API keys not configured" }), {
          status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      try {
        const ts = Date.now();
        const params = new URLSearchParams({ recvWindow: "10000", timestamp: ts.toString() });
        const sig = await hmacSha256(BINANCE_SECRET_KEY, params.toString());
        const res = await fetch(`${BINANCE_BASE}/api/v3/account?${params.toString()}&signature=${sig}`, {
          headers: { "X-MBX-APIKEY": BINANCE_API_KEY },
        });
        const data = await res.json();
        if (data.code) {
          return new Response(JSON.stringify({ error: data.msg, code: data.code }), {
            status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        const filters = await getSymbolFilters();
        const sold: Array<{ asset: string; qty: number; usdtValue: number; orderId: string | null; error: string | null }> = [];

        for (const b of (data.balances ?? []) as Array<{ asset: string; free: string; locked: string }>) {
          if (b.asset === "USDT") continue;
          const free = parseFloat(b.free);
          if (free <= 0) continue;

          const symbol = `${b.asset}USDT`;
          const f = filters.get(symbol);
          if (!f) continue;

          const qty = roundToStep(free, f.stepSize);
          if (qty < f.minQty) continue;

          const result = await placeBinanceOrder(symbol, "SELL", qty, true);
          let usdtValue = 0;
          if (result.orderId) {
            try {
              const tRes = await fetch(`${BINANCE_BASE}/api/v3/ticker/price?symbol=${symbol}`);
              const tData = await tRes.json();
              usdtValue = parseFloat(tData.price) * qty;
            } catch { /* price fetch is best-effort */ }
          }

          sold.push({ asset: b.asset, qty, usdtValue, orderId: result.orderId, error: result.error });

          await checkedWrite(supabase.from("audit_log").insert({
            event_type: "dust_conversion",
            entity_type: "binance",
            entity_id: result.orderId ?? "failed",
            message: `Sold ${qty} ${b.asset} for USDT${result.error ? ` — ERROR: ${result.error}` : ""}`,
            metadata: { asset: b.asset, qty, usdt_value: usdtValue, order_id: result.orderId, error: result.error },
          }), "audit_log insert");
        }

        return new Response(JSON.stringify({ sold, count: sold.length }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      } catch (err) {
        return new Response(JSON.stringify({ error: String(err) }), {
          status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }

    return new Response(JSON.stringify({ error: "Unknown route. Use /prices, /indicators, /scan, /positions, /close-all, /sell-dust, /config, /kill-switch, or /account" }), {
      status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("binance-feed error:", err);
    return new Response(JSON.stringify({ error: err instanceof Error ? err.message : String(err) }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
