/**
 * Swarm allocation loop
 * Multiple strategies compete for capital every cycle.
 * Winners get more size; losers get starved.
 * All decisions logged.
 */

import type { RiskConfig } from '../risk/engine';
import { evaluateRisk, type PositionRisk } from '../risk/engine';

export type StrategyId =
  | 'rsi_oversold'
  | 'rsi_overbought'
  | 'macd_crossover'
  | 'momentum_breakout'
  | 'mean_reversion'
  | 'yield_optimizer'
  | 'health_rebalancer';

export type StrategyScore = {
  id: StrategyId;
  winRate: number; // 0–1
  expectancy: number; // avg $ per trade
  sharpeLike: number;
  recentPnl: number;
  trades: number;
  score: number; // composite
};

export type Allocation = {
  strategy: StrategyId;
  capitalUsd: number;
  weight: number;
  reason: string;
};

export type SwarmDecision = {
  cycleAt: string;
  totalCapital: number;
  allocations: Allocation[];
  blocked: string[];
  riskState: ReturnType<typeof evaluateRisk>;
};

function compositeScore(s: StrategyScore): number {
  // Higher is better. Penalize low sample size.
  const samplePenalty = Math.min(1, s.trades / 30);
  return (
    s.winRate * 0.35 +
    Math.tanh(s.expectancy / 50) * 0.25 +
    Math.tanh(s.sharpeLike) * 0.25 +
    Math.tanh(s.recentPnl / 100) * 0.15
  ) * samplePenalty;
}

export function rankStrategies(scores: StrategyScore[]): StrategyScore[] {
  return scores
    .map((s) => ({ ...s, score: compositeScore(s) }))
    .sort((a, b) => b.score - a.score);
}

/**
 * Allocate capital across top strategies.
 * Bottom performers receive 0 until they prove edge.
 */
export function allocateCapital(
  config: RiskConfig,
  scores: StrategyScore[],
  open: PositionRisk[],
  dailyPnl: number,
  weeklyPnl: number,
): SwarmDecision {
  const ranked = rankStrategies(scores);
  const riskState = evaluateRisk(config, open, dailyPnl, weeklyPnl, 0, null, 'swarm');

  if (!riskState.canOpen || config.killSwitch) {
    return {
      cycleAt: new Date().toISOString(),
      totalCapital: config.treasuryUsd,
      allocations: [],
      blocked: ranked.map((s) => s.id),
      riskState,
    };
  }

  // Only top half of ranked strategies with positive score get capital
  const eligible = ranked.filter((s) => s.score > 0.15 && s.trades >= 5);
  const top = eligible.slice(0, Math.max(1, Math.ceil(eligible.length / 2)));

  if (top.length === 0) {
    return {
      cycleAt: new Date().toISOString(),
      totalCapital: config.treasuryUsd,
      allocations: [],
      blocked: ranked.map((s) => s.id),
      riskState,
    };
  }

  const totalScore = top.reduce((s, x) => s + x.score, 0);
  const deployable = config.treasuryUsd * (1 - config.maxPortfolioHeatPct / 100 / 2); // keep buffer

  const allocations: Allocation[] = top.map((s) => {
    const weight = s.score / totalScore;
    const capitalUsd = Math.floor(deployable * weight);
    return {
      strategy: s.id,
      capitalUsd,
      weight,
      reason: `Score ${s.score.toFixed(3)} · WR ${(s.winRate * 100).toFixed(1)}% · n=${s.trades}`,
    };
  });

  const blocked = ranked
    .filter((s) => !top.some((t) => t.id === s.id))
    .map((s) => s.id);

  return {
    cycleAt: new Date().toISOString(),
    totalCapital: config.treasuryUsd,
    allocations,
    blocked,
    riskState,
  };
}

/** Example default scores (replace with live stats from paper_trades / strategy table) */
export const DEFAULT_SCORES: StrategyScore[] = [
  { id: 'rsi_oversold', winRate: 0.58, expectancy: 12, sharpeLike: 0.9, recentPnl: 40, trades: 42, score: 0 },
  { id: 'macd_crossover', winRate: 0.51, expectancy: 8, sharpeLike: 0.6, recentPnl: 15, trades: 55, score: 0 },
  { id: 'momentum_breakout', winRate: 0.47, expectancy: 22, sharpeLike: 0.7, recentPnl: -10, trades: 28, score: 0 },
  { id: 'mean_reversion', winRate: 0.62, expectancy: 9, sharpeLike: 1.1, recentPnl: 55, trades: 37, score: 0 },
  { id: 'yield_optimizer', winRate: 0.7, expectancy: 4, sharpeLike: 1.4, recentPnl: 30, trades: 20, score: 0 },
  { id: 'health_rebalancer', winRate: 0.85, expectancy: 2, sharpeLike: 1.8, recentPnl: 12, trades: 15, score: 0 },
];
