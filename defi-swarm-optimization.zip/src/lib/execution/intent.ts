/**
 * Execution surface — INTENT ONLY
 * No private keys, no auto-broadcast.
 * Strategies emit signed intents; human or multi-sig must approve.
 * Keep kill switch as hard gate before any broadcast path is added.
 */

export type IntentSide = 'supply' | 'withdraw' | 'borrow' | 'repay' | 'swap' | 'rebalance';

export type ExecutionIntent = {
  id: string;
  strategy: string;
  protocol: string;
  chain: string;
  side: IntentSide;
  asset: string;
  amountUsd: number;
  maxSlippageBps: number;
  healthAfter: number | null;
  createdAt: string;
  status: 'pending' | 'approved' | 'rejected' | 'expired';
  reason: string;
};

export function createIntent(
  partial: Omit<ExecutionIntent, 'id' | 'createdAt' | 'status'>,
): ExecutionIntent {
  return {
    ...partial,
    id: `intent_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    createdAt: new Date().toISOString(),
    status: 'pending',
  };
}

/**
 * Gate: never mark approved if kill switch or risk engine blocks.
 * Real signing + broadcast lives outside this module (viem + Safe / WalletConnect).
 */
export function canApprove(
  intent: ExecutionIntent,
  killSwitch: boolean,
  riskAllows: boolean,
): { ok: boolean; reason: string } {
  if (killSwitch) return { ok: false, reason: 'Kill switch active' };
  if (!riskAllows) return { ok: false, reason: 'Risk engine blocked' };
  if (intent.healthAfter !== null && intent.healthAfter < 1.3) {
    return { ok: false, reason: 'Post-trade health factor too low' };
  }
  return { ok: true, reason: 'Eligible for manual/multisig approval' };
}
