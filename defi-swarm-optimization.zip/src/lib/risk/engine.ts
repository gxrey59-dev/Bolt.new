/**
 * Capital & Risk Engine
 * - Configurable treasury
 * - Position sizing = risk-per-trade × health buffer × correlation
 * - Hard daily/weekly drawdown stops
 * - Auto-delever triggers on health factor
 */

export type RiskConfig = {
  treasuryUsd: number;
  maxRiskPerTradePct: number; // e.g. 1.0 = 1%
  maxPortfolioHeatPct: number; // total open risk
  maxDailyLossPct: number;
  maxWeeklyLossPct: number;
  healthDeleverThreshold: number; // e.g. 1.4
  healthCriticalThreshold: number; // e.g. 1.2
  maxCorrelation: number; // 0–1
  killSwitch: boolean;
  paperMode: boolean;
};

export const DEFAULT_RISK: RiskConfig = {
  treasuryUsd: 10_000, // replace $43 baseline
  maxRiskPerTradePct: 0.75,
  maxPortfolioHeatPct: 6,
  maxDailyLossPct: 3,
  maxWeeklyLossPct: 8,
  healthDeleverThreshold: 1.4,
  healthCriticalThreshold: 1.2,
  maxCorrelation: 0.65,
  killSwitch: false,
  paperMode: true,
};

export type PositionRisk = {
  notionalUsd: number;
  riskUsd: number;
  healthFactor: number | null;
  correlationGroup: string;
};

export type RiskState = {
  config: RiskConfig;
  openRiskUsd: number;
  dailyPnlUsd: number;
  weeklyPnlUsd: number;
  canOpen: boolean;
  reason: string | null;
  suggestedSizeUsd: number;
  mustDelever: boolean;
  critical: boolean;
};

export function evaluateRisk(
  config: RiskConfig,
  open: PositionRisk[],
  dailyPnlUsd: number,
  weeklyPnlUsd: number,
  proposedNotionalUsd: number,
  proposedHealth: number | null,
  proposedGroup: string,
): RiskState {
  if (config.killSwitch) {
    return {
      config,
      openRiskUsd: 0,
      dailyPnlUsd,
      weeklyPnlUsd,
      canOpen: false,
      reason: 'Kill switch active',
      suggestedSizeUsd: 0,
      mustDelever: false,
      critical: false,
    };
  }

  const openRiskUsd = open.reduce((s, p) => s + p.riskUsd, 0);
  const heatPct = (openRiskUsd / config.treasuryUsd) * 100;
  const dailyLossPct = dailyPnlUsd < 0 ? (-dailyPnlUsd / config.treasuryUsd) * 100 : 0;
  const weeklyLossPct = weeklyPnlUsd < 0 ? (-weeklyPnlUsd / config.treasuryUsd) * 100 : 0;

  let mustDelever = false;
  let critical = false;
  for (const p of open) {
    if (p.healthFactor !== null) {
      if (p.healthFactor < config.healthCriticalThreshold) critical = true;
      if (p.healthFactor < config.healthDeleverThreshold) mustDelever = true;
    }
  }
  if (proposedHealth !== null && proposedHealth < config.healthDeleverThreshold) {
    mustDelever = true;
  }

  if (critical || mustDelever) {
    return {
      config,
      openRiskUsd,
      dailyPnlUsd,
      weeklyPnlUsd,
      canOpen: false,
      reason: critical ? 'Critical health factor — delever required' : 'Health below delever threshold',
      suggestedSizeUsd: 0,
      mustDelever,
      critical,
    };
  }

  if (dailyLossPct >= config.maxDailyLossPct) {
    return {
      config,
      openRiskUsd,
      dailyPnlUsd,
      weeklyPnlUsd,
      canOpen: false,
      reason: `Daily loss limit hit (${dailyLossPct.toFixed(2)}%)`,
      suggestedSizeUsd: 0,
      mustDelever,
      critical,
    };
  }

  if (weeklyLossPct >= config.maxWeeklyLossPct) {
    return {
      config,
      openRiskUsd,
      dailyPnlUsd,
      weeklyPnlUsd,
      canOpen: false,
      reason: `Weekly loss limit hit (${weeklyLossPct.toFixed(2)}%)`,
      suggestedSizeUsd: 0,
      mustDelever,
      critical,
    };
  }

  // Correlation check (simple group collision)
  const sameGroup = open.filter((p) => p.correlationGroup === proposedGroup);
  if (sameGroup.length >= 2) {
    return {
      config,
      openRiskUsd,
      dailyPnlUsd,
      weeklyPnlUsd,
      canOpen: false,
      reason: `Correlation group "${proposedGroup}" already at limit`,
      suggestedSizeUsd: 0,
      mustDelever,
      critical,
    };
  }

  const maxRiskUsd = (config.treasuryUsd * config.maxRiskPerTradePct) / 100;
  const remainingHeat = (config.treasuryUsd * config.maxPortfolioHeatPct) / 100 - openRiskUsd;
  const suggested = Math.max(0, Math.min(maxRiskUsd, remainingHeat, proposedNotionalUsd));

  if (suggested <= 0 || heatPct >= config.maxPortfolioHeatPct) {
    return {
      config,
      openRiskUsd,
      dailyPnlUsd,
      weeklyPnlUsd,
      canOpen: false,
      reason: 'Portfolio heat or risk-per-trade limit',
      suggestedSizeUsd: 0,
      mustDelever,
      critical,
    };
  }

  return {
    config,
    openRiskUsd,
    dailyPnlUsd,
    weeklyPnlUsd,
    canOpen: true,
    reason: null,
    suggestedSizeUsd: suggested,
    mustDelever,
    critical,
  };
}

/** Size a new position under risk limits */
export function sizePosition(
  config: RiskConfig,
  open: PositionRisk[],
  dailyPnl: number,
  weeklyPnl: number,
  desiredNotional: number,
  health: number | null,
  group: string,
): { sizeUsd: number; allowed: boolean; reason: string | null } {
  const state = evaluateRisk(config, open, dailyPnl, weeklyPnl, desiredNotional, health, group);
  return {
    sizeUsd: state.suggestedSizeUsd,
    allowed: state.canOpen,
    reason: state.reason,
  };
}
