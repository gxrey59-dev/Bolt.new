/**
 * Multi-RPC mesh with failover, freshness checks, and abort support.
 * Priority: publicnode → drpc → quiknode. All Polygon mainnet only.
 */
const RPCS = [
  'https://polygon-bor-rpc.publicnode.com',
  'https://polygon.drpc.org',
  'https://rpc-mainnet.matic.quiknode.pro',
] as const;

const CHAIN_ID = 137n;
const MAX_BLOCK_AGE_MS = 180_000;
const MAX_FUTURE_SKEW_MS = 30_000;

export type RpcResult = unknown;

export async function rpcCall(
  method: string,
  params: unknown[],
  signal: AbortSignal,
): Promise<RpcResult> {
  let lastError: Error = new Error('All Polygon RPCs failed');
  for (const endpoint of RPCS) {
    if (signal.aborted) throw new DOMException('Aborted', 'AbortError');
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }),
        signal,
      });
      if (!res.ok) {
        lastError = new Error(`RPC HTTP ${res.status} @ ${endpoint}`);
        continue;
      }
      const body = (await res.json()) as {
        error?: { message?: string };
        id?: number;
        result?: unknown;
      };
      if (body.error) {
        lastError = new Error(body.error.message || 'RPC rejected');
        continue;
      }
      if (body.id !== 1 || !('result' in body)) {
        lastError = new Error('Malformed RPC response');
        continue;
      }
      return body.result;
    } catch (err) {
      if (signal.aborted) throw err;
      lastError = err instanceof Error ? err : new Error(String(err));
    }
  }
  throw lastError;
}

export function quantity(value: unknown): bigint {
  if (typeof value !== 'string' || !/^0x[0-9a-f]+$/i.test(value)) {
    throw new Error('Invalid hex RPC value');
  }
  return BigInt(value);
}

export function decimal(value: bigint, scale: bigint, places = 6): string {
  if (scale <= 0n) throw new Error('Invalid scale');
  const whole = value / scale;
  const frac = ((value % scale) * 10n ** BigInt(places)) / scale;
  const fracStr = frac.toString().padStart(places, '0').replace(/0+$/, '');
  return whole.toString() + (fracStr ? '.' + fracStr : '');
}

export function decodeAddress(value: unknown): string {
  if (typeof value !== 'string' || !/^0x[0-9a-f]{64}$/i.test(value)) {
    throw new Error('Invalid address word');
  }
  const address = '0x' + value.slice(-40);
  if (/^0x0{40}$/i.test(address)) throw new Error('Zero address');
  return address;
}

export async function assertPolygon(signal: AbortSignal): Promise<void> {
  const chainId = await rpcCall('eth_chainId', [], signal);
  if (quantity(chainId) !== CHAIN_ID) {
    throw new Error('Wrong network — Polygon mainnet (137) required');
  }
}

export async function getFreshBlock(signal: AbortSignal): Promise<{
  number: string;
  timestamp: number;
}> {
  const blockInfo = (await rpcCall('eth_getBlockByNumber', ['latest', false], signal)) as {
    number?: unknown;
    timestamp?: unknown;
  } | null;
  if (!blockInfo?.number || blockInfo.timestamp === undefined) {
    throw new Error('No block header');
  }
  const blockTime = Number(quantity(blockInfo.timestamp)) * 1000;
  const age = Date.now() - blockTime;
  if (age > MAX_BLOCK_AGE_MS || age < -MAX_FUTURE_SKEW_MS) {
    throw new Error('Stale or skewed block timestamp');
  }
  return {
    number: String(blockInfo.number),
    timestamp: blockTime,
  };
}
