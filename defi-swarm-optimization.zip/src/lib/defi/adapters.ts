/**
 * Protocol adapter interface + registry.
 * Each adapter returns normalized position + risk + yield metrics.
 * Only Aave is live; others are stubs ready for implementation.
 */
import type { AaveSnapshot } from './aave';
import { readAaveSnapshot } from './aave';

export type ProtocolId = 'aave-v3' | 'uniswap-v3' | 'curve' | 'balancer' | 'compound-v3';

export type NormalizedPosition = {
  protocol: ProtocolId;
  chain: string;
  wallet: string | null;
  collateralUsd: string | null;
  debtUsd: string | null;
  healthFactor: string | null;
  availableBorrowUsd: string | null;
  ltv: string | null;
  liquidationThreshold: string | null;
  nativeBalance: string | null;
  apySupply: string | null; // null until real rate feed
  apyBorrow: string | null;
  lastBlock: string;
  checkedAt: string;
  status: 'live' | 'stub' | 'error';
  error?: string;
};

export interface ProtocolAdapter {
  id: ProtocolId;
  name: string;
  chain: string;
  faction: string;
  icon: string;
  read(wallet: string, signal: AbortSignal): Promise<NormalizedPosition>;
}

function aaveToNormalized(s: AaveSnapshot): NormalizedPosition {
  return {
    protocol: 'aave-v3',
    chain: 'Polygon',
    wallet: s.wallet,
    collateralUsd: s.collateral,
    debtUsd: s.debt,
    healthFactor: s.health,
    availableBorrowUsd: s.availableBorrows,
    ltv: s.ltv,
    liquidationThreshold: s.currentLiquidationThreshold,
    nativeBalance: s.nativeBalance,
    apySupply: null,
    apyBorrow: null,
    lastBlock: s.block,
    checkedAt: s.checkedAt,
    status: 'live',
  };
}

const aaveAdapter: ProtocolAdapter = {
  id: 'aave-v3',
  name: 'Cuban Linx Yield Cooperative',
  chain: 'Polygon',
  faction: 'The Chef',
  icon: '👻',
  async read(wallet, signal) {
    const snap = await readAaveSnapshot(wallet, signal);
    return aaveToNormalized(snap);
  },
};

function stubAdapter(
  id: ProtocolId,
  name: string,
  chain: string,
  faction: string,
  icon: string,
): ProtocolAdapter {
  return {
    id,
    name,
    chain,
    faction,
    icon,
    async read() {
      return {
        protocol: id,
        chain,
        wallet: null,
        collateralUsd: null,
        debtUsd: null,
        healthFactor: null,
        availableBorrowUsd: null,
        ltv: null,
        liquidationThreshold: null,
        nativeBalance: null,
        apySupply: null,
        apyBorrow: null,
        lastBlock: '—',
        checkedAt: new Date().toISOString(),
        status: 'stub',
        error: 'Adapter requires protocol-specific integration + rate feeds',
      };
    },
  };
}

export const ADAPTERS: ProtocolAdapter[] = [
  aaveAdapter,
  stubAdapter('uniswap-v3', 'Liquid Swords Swarm', 'Arbitrum', 'The Genius', '🦄'),
  stubAdapter('curve', 'Supreme Clientele Pool', 'Ethereum', 'Tony Starks', '🌊'),
  stubAdapter('balancer', 'Golden Arms Bridge Swarm', 'Optimism', 'U-God', '⚖️'),
  stubAdapter('compound-v3', 'Tical Flash Swarm', 'Base', 'Meth Lab', '📊'),
];

export async function readAllPositions(
  wallet: string,
  signal: AbortSignal,
): Promise<NormalizedPosition[]> {
  const results = await Promise.allSettled(
    ADAPTERS.map((a) => a.read(wallet, signal)),
  );
  return results.map((r, i) => {
    if (r.status === 'fulfilled') return r.value;
    return {
      protocol: ADAPTERS[i].id,
      chain: ADAPTERS[i].chain,
      wallet: wallet || null,
      collateralUsd: null,
      debtUsd: null,
      healthFactor: null,
      availableBorrowUsd: null,
      ltv: null,
      liquidationThreshold: null,
      nativeBalance: null,
      apySupply: null,
      apyBorrow: null,
      lastBlock: '—',
      checkedAt: new Date().toISOString(),
      status: 'error' as const,
      error: r.reason instanceof Error ? r.reason.message : 'Read failed',
    };
  });
}
