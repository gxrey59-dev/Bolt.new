/**
 * Aave V3 Polygon adapter — hardened position + reserve reader.
 * Uses canonical AddressesProvider. Resolves pool + oracle at same block.
 */
import {
  rpcCall,
  quantity,
  decimal,
  decodeAddress,
  assertPolygon,
  getFreshBlock,
} from './rpc';

const PROVIDER = '0xa97684ead0e402dC232d5A977953DF7ECBaB3CDb';
const addressPattern = /^0x[0-9a-fA-F]{40}$/;

export type AaveSnapshot = {
  block: string;
  blockTime: number;
  checkedAt: string;
  pool: string;
  oracle: string;
  wallet: string | null;
  nativeBalance: string | null;
  collateral: string | null;
  debt: string | null;
  health: string | null;
  currency: string;
  availableBorrows: string | null;
  currentLiquidationThreshold: string | null;
  ltv: string | null;
};

export async function readAaveSnapshot(
  wallet: string,
  signal: AbortSignal,
): Promise<AaveSnapshot> {
  const trimmed = wallet.trim();
  if (trimmed && (!addressPattern.test(trimmed) || /^0x0{40}$/i.test(trimmed))) {
    throw new Error('Invalid nonzero public wallet address');
  }

  await assertPolygon(signal);
  const { number: blockHex, timestamp: blockTime } = await getFreshBlock(signal);

  const call = (to: string, data: string) =>
    rpcCall('eth_call', [{ to, data }, blockHex], signal);

  // getPool()
  const pool = decodeAddress(await call(PROVIDER, '0x026b1d5f'));
  const code = await rpcCall('eth_getCode', [pool, blockHex], signal);
  if (typeof code !== 'string' || code === '0x' || code === '0x0') {
    throw new Error('Aave pool has no bytecode');
  }

  // getPriceOracle()
  const oracle = decodeAddress(await call(PROVIDER, '0xfca513a8'));

  const result: AaveSnapshot = {
    block: quantity(blockHex).toString(),
    blockTime,
    checkedAt: new Date().toISOString(),
    pool,
    oracle,
    wallet: trimmed || null,
    nativeBalance: null,
    collateral: null,
    debt: null,
    health: null,
    currency: '',
    availableBorrows: null,
    currentLiquidationThreshold: null,
    ltv: null,
  };

  if (!trimmed) return result;

  // getUserAccountData(address)
  const accountData =
    '0xbf92857c' + trimmed.slice(2).toLowerCase().padStart(64, '0');

  const [account, balance, unit, base] = await Promise.all([
    call(pool, accountData),
    rpcCall('eth_getBalance', [trimmed, blockHex], signal),
    call(oracle, '0x8c89b64f'), // BASE_CURRENCY_UNIT
    call(oracle, '0xe19f4700'), // BASE_CURRENCY
  ]);

  if (typeof account !== 'string' || !/^0x[0-9a-f]{384}$/i.test(account)) {
    throw new Error('Unexpected Aave account data shape');
  }

  const words = Array.from({ length: 6 }, (_, i) =>
    BigInt('0x' + account.slice(2 + i * 64, 2 + (i + 1) * 64)),
  );

  // words: [totalCollateralBase, totalDebtBase, availableBorrowsBase, currentLiquidationThreshold, ltv, healthFactor]
  const unitBn = quantity(unit);
  result.currency =
    typeof base === 'string' && quantity(base) === 0n ? 'USD' : decodeAddress(base);

  result.nativeBalance = decimal(quantity(balance), 10n ** 18n, 6);
  result.collateral = decimal(words[0], unitBn, 2);
  result.debt = decimal(words[1], unitBn, 2);
  result.availableBorrows = decimal(words[2], unitBn, 2);
  result.currentLiquidationThreshold = decimal(words[3], 100n, 2) + '%';
  result.ltv = decimal(words[4], 100n, 2) + '%';
  result.health =
    words[1] === 0n ? 'No debt' : decimal(words[5], 10n ** 18n, 4);

  return result;
}

/** Health factor risk levels for circuit breakers */
export function healthRisk(health: string | null): 'safe' | 'watch' | 'danger' | 'critical' | 'none' {
  if (!health || health === 'No debt') return 'none';
  const h = parseFloat(health);
  if (isNaN(h)) return 'none';
  if (h >= 2.0) return 'safe';
  if (h >= 1.5) return 'watch';
  if (h >= 1.2) return 'danger';
  return 'critical';
}
