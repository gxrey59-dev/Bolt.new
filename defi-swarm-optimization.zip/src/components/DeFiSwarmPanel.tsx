/**
 * Hardened DeFi Swarm Panel
 * - Multi-RPC Aave V3 live monitor
 * - Adapter registry (Aave live, others stubbed cleanly)
 * - Risk-aware status
 * - No fake yield numbers
 */
import { useEffect, useRef, useState } from 'react';
import {
  Network, Bot, Boxes, DollarSign, Percent, Activity,
  ChevronRight, ChevronDown, RefreshCw, Wallet, Square, Play, AlertTriangle,
} from 'lucide-react';
import { ADAPTERS, readAllPositions, type NormalizedPosition } from '@/lib/defi/adapters';
import { healthRisk } from '@/lib/defi/aave';
import { DEFAULT_RISK, type RiskConfig } from '@/lib/risk/engine';

const addressPattern = /^0x[0-9a-fA-F]{40}$/;
const DEFAULT_WALLET = '';

export default function DeFiSwarmPanel() {
  const [wallet, setWallet] = useState(DEFAULT_WALLET);
  const [running, setRunning] = useState(false);
  const [tick, setTick] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [walletMsg, setWalletMsg] = useState('');
  const [positions, setPositions] = useState<NormalizedPosition[]>([]);
  const [expanded, setExpanded] = useState<string | null>('aave-v3');
  const [risk] = useState<RiskConfig>(DEFAULT_RISK);

  const abortRef = useRef<AbortController | null>(null);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const disposedRef = useRef(false);

  useEffect(() => {
    disposedRef.current = false;
    if (!running) {
      return () => { disposedRef.current = true; };
    }

    async function poll() {
      if (disposedRef.current) return;
      abortRef.current?.abort();
      const controller = new AbortController();
      abortRef.current = controller;
      setLoading(true);

      try {
        const next = await readAllPositions(wallet, controller.signal);
        if (!disposedRef.current && !controller.signal.aborted) {
          setPositions(next);
          setError('');
        }
      } catch (cause) {
        if (disposedRef.current || controller.signal.aborted) return;
        if ((cause as Error)?.name === 'AbortError') return;
        setPositions([]);
        setError(cause instanceof Error ? cause.message : 'Live check failed');
      } finally {
        if (!disposedRef.current) setLoading(false);
        if (!disposedRef.current && running) {
          timerRef.current = setTimeout(() => void poll(), 30_000);
        }
      }
    }

    void poll();
    return () => {
      disposedRef.current = true;
      abortRef.current?.abort();
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [running, wallet, tick]);

  function stop() {
    setRunning(false);
    abortRef.current?.abort();
    if (timerRef.current) clearTimeout(timerRef.current);
    setPositions([]);
    setLoading(false);
    setError('');
  }

  function start() {
    setError('');
    setWalletMsg('');
    setPositions([]);
    setRunning(true);
    setTick((n) => n + 1);
  }

  async function connectWallet() {
    setWalletMsg('');
    try {
      const eth = (window as Window & { ethereum?: { request: (a: { method: string }) => Promise<unknown> } }).ethereum;
      if (!eth) {
        setWalletMsg('No browser wallet. Enter public address for read-only checks. No private key needed.');
        return;
      }
      const accounts = await eth.request({ method: 'eth_requestAccounts' });
      if (!Array.isArray(accounts) || typeof accounts[0] !== 'string' || !addressPattern.test(accounts[0])) {
        setWalletMsg('Wallet returned no valid account.');
        return;
      }
      setWallet(accounts[0]);
      setWalletMsg('');
      setError('');
      setRunning(true);
      setTick((n) => n + 1);
    } catch (cause) {
      setWalletMsg(cause instanceof Error ? cause.message : 'Wallet connection declined.');
    }
  }

  const aave = positions.find((p) => p.protocol === 'aave-v3' && p.status === 'live');
  const healthy = running && !!aave && !error;
  const riskLevel = healthRisk(aave?.healthFactor ?? null);

  const stats = [
    { label: 'Verified collateral', value: aave?.collateralUsd ? `${aave.collateralUsd} ${aave.protocol === 'aave-v3' ? 'USD' : ''}` : '—', icon: Boxes },
    { label: 'Debt', value: aave?.debtUsd ?? '—', icon: DollarSign },
    { label: 'Health factor', value: aave?.healthFactor ?? '—', icon: Activity },
    { label: 'Available borrow', value: aave?.availableBorrowUsd ?? '—', icon: Percent },
    { label: 'Live monitors', value: healthy ? String(positions.filter((p) => p.status === 'live').length) : '—', icon: Bot },
    { label: 'Risk mode', value: risk.paperMode ? 'PAPER' : 'LIVE', icon: AlertTriangle },
  ];

  return (
    <section className="space-y-5">
      <div className="flex flex-wrap items-center gap-3">
        <Network className="h-5 w-5 text-cyan-400" />
        <h2 className="text-lg font-bold text-zinc-100">DeFi Swarm Intelligence</h2>
        <span
          className={`rounded-full px-3 py-1 text-[11px] font-bold ${
            healthy
              ? 'bg-emerald-500/15 text-emerald-400'
              : error
                ? 'bg-red-500/15 text-red-400'
                : running
                  ? 'bg-cyan-500/15 text-cyan-400'
                  : 'bg-zinc-800 text-zinc-400'
          }`}
        >
          {healthy ? 'ON-CHAIN MONITORING' : error ? 'CONNECTION ERROR' : running ? 'CONNECTING' : 'NOT RUNNING'}
        </span>
        {riskLevel === 'critical' && (
          <span className="rounded-full bg-red-500/20 px-3 py-1 text-[11px] font-bold text-red-400">
            CRITICAL HEALTH
          </span>
        )}
        {riskLevel === 'danger' && (
          <span className="rounded-full bg-amber-500/20 px-3 py-1 text-[11px] font-bold text-amber-400">
            DELEVER ZONE
          </span>
        )}
      </div>

      <div className="space-y-3 rounded-xl border border-zinc-800 bg-zinc-900/60 p-4">
        <div className="flex flex-wrap gap-2">
          <input
            aria-label="Public wallet address"
            value={wallet}
            onChange={(e) => {
              stop();
              setWallet(e.target.value);
              setWalletMsg('');
            }}
            placeholder="Public wallet address (0x…)"
            className="min-w-64 flex-1 rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2 font-mono text-sm text-zinc-200"
            spellCheck={false}
          />
          <button
            type="button"
            onClick={() => void connectWallet()}
            className="rounded-lg bg-zinc-800 px-3 py-2 text-sm text-zinc-200 hover:bg-zinc-700"
          >
            <Wallet className="mr-2 inline h-4 w-4" />
            Connect wallet
          </button>
          <button
            type="button"
            disabled={loading && running}
            onClick={() => (running ? stop() : start())}
            className={`rounded-lg px-3 py-2 text-sm text-white disabled:opacity-50 ${
              running ? 'bg-red-600/80 hover:bg-red-600' : 'bg-cyan-600 hover:bg-cyan-500'
            }`}
          >
            {running ? (
              <><Square className="mr-2 inline h-4 w-4" />Stop</>
            ) : (
              <><Play className="mr-2 inline h-4 w-4" />Run live checks</>
            )}
          </button>
        </div>
        <p className="text-xs text-zinc-500">
          Polygon · Aave V3 live · multi-RPC failover · 30s poll. Public address only. No private key.
        </p>
        <p className="text-xs text-zinc-400">
          Strategy execution and capital deployment remain gated by risk engine + kill switch. Paper mode default.
        </p>
        {walletMsg && <p className="text-sm text-amber-300">{walletMsg}</p>}
        {error && <p role="alert" className="text-sm text-red-300">{error}</p>}
        {aave && (
          <p role="status" className="text-xs text-cyan-400">
            Block {aave.lastBlock} · {aave.checkedAt}
            {aave.wallet ? ` · ${aave.wallet}` : ''}
          </p>
        )}
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        {stats.map((stat) => (
          <div key={stat.label} className="rounded-xl border border-zinc-800 bg-gradient-to-br from-zinc-900/80 to-zinc-950/80 p-4">
            <div className="mb-1.5 flex items-center gap-1.5">
              <stat.icon className="h-3.5 w-3.5 text-cyan-400" />
              <p className="text-[10px] uppercase tracking-wider text-zinc-500">{stat.label}</p>
            </div>
            <p className="break-all font-mono text-xl font-bold text-zinc-100">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="space-y-3">
        {ADAPTERS.map((adapter) => {
          const pos = positions.find((p) => p.protocol === adapter.id);
          const open = expanded === adapter.id;
          const isLive = pos?.status === 'live';
          return (
            <div key={adapter.id} className="overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-900/60">
              <button
                aria-expanded={open}
                onClick={() => setExpanded(open ? null : adapter.id)}
                className="flex w-full items-center gap-4 p-5 text-left"
              >
                {open ? <ChevronDown className="h-4 w-4 text-zinc-500" /> : <ChevronRight className="h-4 w-4 text-zinc-500" />}
                <span className="text-2xl">{adapter.icon}</span>
                <div className="flex-1">
                  <h3 className="text-sm font-bold text-zinc-200">{adapter.name}</h3>
                  <p className="text-[10px] text-zinc-500">
                    {adapter.chain} · {adapter.faction} · {adapter.id}
                  </p>
                </div>
                <span
                  className={`rounded-full px-2 py-1 text-[10px] font-bold ${
                    isLive
                      ? 'bg-emerald-500/15 text-emerald-400'
                      : pos?.status === 'error'
                        ? 'bg-red-500/15 text-red-400'
                        : 'bg-zinc-800 text-zinc-400'
                  }`}
                >
                  {isLive ? 'MONITORING' : pos?.status === 'error' ? 'ERROR' : 'ADAPTER READY'}
                </span>
                <div className="hidden text-right sm:block">
                  <p className="text-[9px] text-zinc-500">COLLATERAL</p>
                  <p className="font-mono text-sm text-zinc-200">
                    {isLive && pos?.collateralUsd ? pos.collateralUsd : '—'}
                  </p>
                </div>
              </button>
              {open && (
                <div className="space-y-3 border-t border-zinc-800 p-5 text-xs text-zinc-400">
                  {isLive && pos ? (
                    <>
                      <p>
                        Live checks: chain ID, block freshness, pool bytecode, wallet balance, full Aave account data at same block.
                      </p>
                      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
                        <div>
                          Native
                          <p className="mt-1 font-mono text-zinc-200">{pos.nativeBalance ?? '—'}</p>
                        </div>
                        <div>
                          Debt
                          <p className="mt-1 font-mono text-zinc-200">{pos.debtUsd ?? '—'}</p>
                        </div>
                        <div>
                          Health
                          <p className="mt-1 font-mono text-zinc-200">{pos.healthFactor ?? '—'}</p>
                        </div>
                        <div>
                          LTV / Liq
                          <p className="mt-1 font-mono text-zinc-200">
                            {pos.ltv ?? '—'} / {pos.liquidationThreshold ?? '—'}
                          </p>
                        </div>
                      </div>
                    </>
                  ) : (
                    <p>
                      {pos?.error ||
                        'Requires protocol adapter, position discovery, and confirmed rate feeds. No estimated earnings shown.'}
                    </p>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="rounded-xl border border-zinc-800 bg-zinc-900/40 p-4 text-xs text-zinc-500">
        <p className="font-semibold text-zinc-400">Risk engine active</p>
        <p className="mt-1">
          Treasury ${risk.treasuryUsd.toLocaleString()} · Max risk/trade {risk.maxRiskPerTradePct}% · Heat cap{' '}
          {risk.maxPortfolioHeatPct}% · Daily loss {risk.maxDailyLossPct}% · Delever @ HF &lt; {risk.healthDeleverThreshold} ·
          Paper mode: {risk.paperMode ? 'ON' : 'OFF'}
        </p>
      </div>
    </section>
  );
}
