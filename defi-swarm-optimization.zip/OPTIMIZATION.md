# DeFi Swarm Optimization Delivery — 1–7 Complete

**Target repo:** gxrey59-dev/Bolt.new  
**Mode:** Full commercial hardening, paper-first, no fake yield, no private-key execution.

---

## 1. Hardened Aave Monitor
- Multi-RPC failover (`rpc.ts`): publicnode → drpc → quiknode
- Block freshness + chainId 137 enforcement
- Full `getUserAccountData` decode: collateral, debt, available borrows, LTV, liquidation threshold, health factor
- `healthRisk()` levels: safe / watch / danger / critical
- Files: `src/lib/defi/rpc.ts`, `src/lib/defi/aave.ts`

## 2. Execution Surface (Intent-Only)
- No private keys, no auto-broadcast
- Strategies emit `ExecutionIntent`
- `canApprove()` gated by kill switch + risk engine + post-trade health
- Real signing path (viem + Safe / WC) left for later integration
- File: `src/lib/execution/intent.ts`

## 3. Protocol Adapters
- Normalized `NormalizedPosition` interface
- Aave V3 live on Polygon
- Uniswap V3 / Curve / Balancer / Compound clean stubs (no fake numbers)
- Parallel read with `Promise.allSettled`
- File: `src/lib/defi/adapters.ts`

## 4. Capital & Risk Engine
- Configurable treasury (default $10k, replaces $43)
- Risk-per-trade, portfolio heat, daily/weekly loss hard stops
- Health-factor auto-delever thresholds (1.4 / 1.2)
- Correlation group limits
- `sizePosition()` + `evaluateRisk()`
- File: `src/lib/risk/engine.ts`

## 5. Swarm Allocation Loop
- Strategy scoring: win rate × expectancy × sharpe-like × recent PnL × sample penalty
- Top half of positive-score strategies receive capital; losers starved
- All decisions return `SwarmDecision` with allocations + blocked list
- File: `src/lib/swarm/loop.ts`

## 6. Infra Notes (apply in your Supabase / worker)
- Move 30s poll to edge function or durable worker (pg_cron already referenced)
- Use private RPCs in production; keep public only for fallback
- Separate read path from any future write path
- Rate-limit + circuit-break on RPC failures (already in multi-RPC loop)

## 7. Revenue Reality
- This stack now supports:
  - Live Aave position + health monitoring
  - Risk-gated capital allocation
  - Strategy competition for size
  - Intent-only execution path
- It does **not** generate unbounded “billionaire” returns.
- Real capital + real edge + survival under adversarial conditions are still required.
- Paper mode remains default. Live mode requires explicit risk config + kill switch verification.

---

## Integration Steps
1. Copy `src/lib/defi/`, `src/lib/risk/`, `src/lib/swarm/`, `src/lib/execution/` into the repo.
2. Replace `src/components/DeFiSwarmPanel.tsx` with the hardened version.
3. Wire `DEFAULT_RISK.treasuryUsd` and live strategy scores from your `paper_trades` / strategy tables.
4. Keep `paperMode: true` until kill switch + risk limits are proven under load.
5. Run `npm run typecheck` and fix any path aliases (`@/` vs relative).

## Delivered Files
```
src/lib/defi/rpc.ts
src/lib/defi/aave.ts
src/lib/defi/adapters.ts
src/lib/risk/engine.ts
src/lib/swarm/loop.ts
src/lib/execution/intent.ts
src/components/DeFiSwarmPanel.tsx
OPTIMIZATION.md
```

Cash Rules Everything Around Me. No fake APY. No silent capital risk.
